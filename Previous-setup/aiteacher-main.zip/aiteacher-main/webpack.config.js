const webpack = require('webpack');

module.exports = {
  resolve: {
    fallback: {
      fs: false,
      http: require.resolve('stream-http'),
      https: require.resolve('https-browserify'),
      url: require.resolve('url/'),
    },
  },
  plugins: [
    new webpack.ProvidePlugin({
      process: 'process/browser',
    }),
  ],
  devServer: {
    setupMiddlewares: (middlewares, devServer) => {
      // Add your custom middlewares here
      // Example:
      // devServer.app.use((req, res, next) => {
      //   console.log('Custom middleware');
      //   next();
      // });

      return middlewares;
    },
  },
};
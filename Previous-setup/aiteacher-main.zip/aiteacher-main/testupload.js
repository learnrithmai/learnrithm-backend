const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs');

const filePath = 'upload.pdf'; // Replace with your file path

const formData = new FormData();
formData.append('file', fs.createReadStream(filePath));

axios.post('https://aiteacher.learnrithm.com/api/upload', formData, {
  headers: {
    ...formData.getHeaders(),
  },
})
  .then(response => {
    console.log('Upload successful:', response.data);
  })
  .catch(error => {
    console.error('Error uploading file:', error.response ? error.response.data : error.message);
  });
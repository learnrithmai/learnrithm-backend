const express = require("express");
const mongoose = require("mongoose");
const cron = require("node-cron");
const bodyParser = require("body-parser");
const nodemailer = require("nodemailer");
const cors = require("cors");
const pdfParse = require("pdf-parse");
const multer = require("multer");
const cloudinary = require('cloudinary').v2;
const upload = multer({ storage: multer.memoryStorage() });
const mammoth = require("mammoth");
const Tesseract = require("tesseract.js");
const crypto = require("crypto");
require("dotenv").config();
const path = require("path");
const gis = require("g-i-s");
const youtubesearchapi = require("youtube-search-api");
const { YoutubeTranscript } = require("youtube-transcript");
const {
  GoogleGenerativeAI,
  HarmBlockThreshold,
  HarmCategory,
} = require("@google/generative-ai");
const { createApi } = require("unsplash-js");
const {getSubtitles } = require('youtube-captions-scraper');

const showdown = require("showdown");
const axios = require("axios");
const { startOfWeek, endOfWeek, format } = require("date-fns");
const Flutterwave = require("flutterwave-node-v3");
const {
  languages,
  logo,
  name,
  partnerServer,
  websiteURL,
  serverURL,
  company,
  quizURL,
} = require("../src/constants");
const flw = new Flutterwave(
  process.env.FLUTTERWAVE_PUBLIC_KEY,
  process.env.FLUTTERWAVE_SECRET_KEY
);

const app = express();

app.use(cors());
const PORT = process.env.PORT;
app.use(bodyParser.json());

const url = process.env.MONGODB_URI;

if (!url) {
  console.log("error fetching url");
}

mongoose.connect(url, {});
const transporter = nodemailer.createTransport({
  host: "smtppro.zoho.com",
  port: 587,
  secure: false,
  auth: {
    user: process.env.EMAIL,
    pass: process.env.PASSWORD,
  },
  tls: {
    rejectUnauthorized: false,
  },
});

const genAI = new GoogleGenerativeAI(process.env.API_KEY);
const unsplash = createApi({ accessKey: process.env.UNSPLASH_ACCESS_KEY });

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});
//SCHEMA

const messageSchema = new mongoose.Schema({
  sender: { type: String, required: true },
  text: { type: String, required: true },
  imageUrl: { type: String, default: "" },
  timestamp: { type: Date, default: Date.now },
});



const adminSchema = new mongoose.Schema({
  email: { type: String, unique: true, required: true },
  mName: String,
  type: { type: String, required: true },
  total: { type: Number, default: 0 },
  terms: { type: String, default: "" },
  privacy: { type: String, default: "" },
  cancel: { type: String, default: "" },
  refund: { type: String, default: "" },
  billing: { type: String, default: "" },
});

const userSchema = new mongoose.Schema({
  email: { type: String, unique: true, required: true },
  isVerified: { type: Boolean, default: false },
  emailToken: { type: String },
  emailTokenExpires: { type: Date },
  mName: String,
  password: { type: String, required: true },
  type: { type: String, default: "free" },
  plan: { type: String, default: "hobby" },
  signUpApp: { type: String, default: "AITeacher" },
  resetPasswordToken: { type: String, default: null },
  resetPasswordExpires: { type: Date, default: null },
  date: { type: Date, default: Date.now },
  refUserMail: String,
  streakId: { type: String },
  lastLogin: { type: Date, default: null },
  country: String,
});

const courseSchema = new mongoose.Schema({
  user: String,
  email: String,
  content: { type: String, required: true },
  type: String,
  mainTopic: String,
  language: typeof languages,
  photo: String,
  date: { type: Date, default: Date.now },
  end: { type: Date, default: Date.now },
  completed: { type: Boolean, default: false },
});
const subscriptionSchema = new mongoose.Schema({
  user: String,
  subscription: String,
  subscriberId: String,
  type: String,
  method: String,
  date: { type: Date, default: Date.now },
  active: { type: Boolean, default: true },
});
const contactShema = new mongoose.Schema({
  fname: String,
  lname: String,
  email: String,
  phone: Number,
  msg: String,
  date: { type: Date, default: Date.now },
});
const streaker = new mongoose.Schema({
  userId: { type: String, required: true },
  email: { type: String, required: true },
  signQuiz: { type: Boolean, default: false },
  signQuizNotify: { type: Boolean, default: false },
  signTeacherNotify: { type: Boolean, default: false },
  signTeacher: { type: Boolean, default: false },
  dateStrekingQuiz: { type: Date, default: Date.now },
  dateStrekingCourse: { type: Date, default: Date.now },
  courseDo: { type: Boolean, default: false },
  courseNotify: { type: Boolean, default: false },
  quizDo: { type: Boolean, default: false },
  quizNotify: { type: Boolean, default: false },
  quizStreakCount: { type: Number, default: 0 },
  teacherStreakCount: { type: Number, default: 0 },
});

const RefUserSchema = new mongoose.Schema({
  _id: { type: String, required: true },
  app: { type: String, required: true },
  date: { type: Date, required: true },
  email: { type: String, required: true },
  isPaid: { type: String, required: true },
  isVerified: { type: Boolean, required: true },
  partnerId: { type: String, required: true },
  refCoUsed: { type: String, required: true },
  userRefMail: { type: String, required: true }
});

const transactionSchema = new mongoose.Schema(
  {
    email: { type: String, required: true, unique: true },
    duration: { type: String, required: true },
    subscriptionStart: { type: Date, required: true },
    subscriptionEnd: { type: Date, required: true },
    orderId: { type: String, required: true },
    createdAt: { type: Date, default: Date.now },
  },
  { timestamps: true }
);

//MODEL
const User = mongoose.model("User", userSchema);
const Course = mongoose.model("Course", courseSchema);
const Subscription = mongoose.model("Subscription", subscriptionSchema);
const Contact = mongoose.model("Contact", contactShema);
const Admin = mongoose.model("Admin", adminSchema);
const Streaker = mongoose.model("Streak", streaker);
const Transaction = mongoose.model("Transaction", transactionSchema);
const Message = mongoose.model("Message", messageSchema);
const RefUser = mongoose.model('RefUser', RefUserSchema);






app.post('/api/webhook', async (req, res) => {
  const signature = req.headers['x-signature'];
  const payload = req.rawBody;

  console.log('Received payload:', payload);
  console.log('Received signature:', signature);

  const secret = process.env.LEMON_SQUEEZY_WEBHOOK_SECRET;

  if (!secret) {
      console.error('LEMON_SQUEEZY_SIGNING_SECRET not set');
      return res.status(500).send('Server error');
  }

  // Create HMAC using the raw payload
  const hmac = crypto.createHmac('sha256', secret)
                     .update(payload)
                     .digest('hex');

  console.log('Computed HMAC:', hmac);

  // Convert both signatures to buffers
  const receivedSignature = Buffer.from(signature, 'hex');
  const expectedSignature = Buffer.from(hmac, 'hex');

  if (receivedSignature.length === 0 || expectedSignature.length === 0) {
      return res.status(400).send('Invalid signature');
  }

  // Compare signatures using timingSafeEqual
  if (!crypto.timingSafeEqual(receivedSignature, expectedSignature)) {
      return res.status(400).send('Invalid signature');
  }

  const event = req.body;

  // Update event type check
  if (event.meta && event.meta.event_name === 'subscription_cancelled') {
      const email = event.data.attributes.user_email; // Updated field

      try {
          const user = await User.findOne({ email });
          if (user) {
              user.type = 'free';
              await user.save();
              res.status(200).send('Subscription type updated to free');
          } else {
              res.status(404).send('User not found');
          }
      } catch (error) {
          console.error(error);
          res.status(500).send('Server error');
      }
  } else {
      res.status(400).send('Unhandled event type');
  }
});

const checkAndUpdateExpiredSubscriptions = async () => {
  try {
    const now = new Date();
    const expiredSubscriptions = await Transaction.find({
      subscriptionEnd: { $lt: now },
    });

    for (const subscription of expiredSubscriptions) {
      const user = await User.findOne({ email: subscription.email });
      if (user) {
        user.type = "free";
        await user.save();
      }
    }
  } catch (error) {
    console.error("Error checking and updating expired subscriptions:", error);
  }
};

cron.schedule("0 0 * * *", checkAndUpdateExpiredSubscriptions);

app.post("/api/transactions", async (req, res) => {
  console.log("Incoming request body:", req.body);
  const { email, duration, subscriptionStart, subscriptionEnd, orderId } = req.body;

  try {
    const existingTransaction = await Transaction.findOne({ email });

    if (existingTransaction) {
      existingTransaction.duration = duration;
      existingTransaction.subscriptionStart = new Date(subscriptionStart);
      existingTransaction.subscriptionEnd = new Date(subscriptionEnd);
      existingTransaction.orderId = orderId;

      await existingTransaction.save();

      const refUser = await RefUser.findOne({ userRefMail: email });
      if (refUser) {
        await RefUser.findOneAndUpdate(
          { userRefMail: email },
          { isPaid: duration }
        );
      }

      return res.status(200).json({
        message: "Transaction updated successfully",
        transaction: existingTransaction,
      });
    } else {
      const transaction = new Transaction({
        email,
        duration,
        subscriptionStart,
        subscriptionEnd,
        orderId,
      });
      await transaction.save();

      const refUser = await RefUser.findOne({ userRefMail: email });
      if (refUser) {
        await RefUser.findOneAndUpdate(
          { userRefMail: email },
          { isPaid: duration }
        );
      }

      return res.status(201).json({
        message: "Transaction saved successfully",
        transaction,
      });
    }
  } catch (error) {
    console.error("Error saving/updating transaction:", error);
    res.status(400).json({ message: error.message });
  }
});







// GET TRANSACTION DETAILS
app.get("/api/transactions", async (req, res) => {
  const { email } = req.query;

  try {
    const transactions = await Transaction.find({ email }).sort({
      createdAt: -1,
    }); // Sort by createdAt descending
    res.status(200).json(transactions);
  } catch (error) {
    console.error("Error fetching transactions:", error);
    res.status(500).json({ message: "Error fetching transactions" });
  }
});

// Update User Plan
app.post("/api/updateUserPlan", async (req, res) => {
  const { email, plan } = req.body;

  try {
    const user = await User.findOneAndUpdate(
      { email: email.toLowerCase() },
      { $set: { type: plan } },
      { new: true }
    );

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    res.status(200).json({ message: "User plan updated successfully", user });
  } catch (error) {
    console.error("Error updating user plan:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});

// Import the Message model

app.post('/api/chatbot', async (req, res) => {
  const { prompt } = req.body;

  if (!prompt) {
    return res.status(400).json({ success: false, message: 'Prompt is required' });
  }

  const safetySettings = [
    {
      category: HarmCategory.HARM_CATEGORY_HARASSMENT,
      threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
    },
    {
      category: HarmCategory.HARM_CATEGORY_DEROGATORY,
      threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
    },
    {
      category: HarmCategory.HARM_CATEGORY_VIOLENCE,
      threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
    },
    // Add other safety settings as needed
  ];

  try {
    // Save the user's message to the database
    const userMessage = new Message({
      sender: 'user',
      text: prompt,
    });
    await userMessage.save();

    const messages = [
      {
        author: 'user',
        content: prompt,
      },
    ];

    const response = await palm.chat(messages, {
      temperature: 0.8,
      candidateCount: 1,
      top_k: 40,
      top_p: 0.95,
      safetySettings: safetySettings,
    });

    const botResponse = response.candidates[0].content;

    // Save the chatbot's response to the database
    const chatbotMessage = new Message({
      sender: 'chatbot',
      text: botResponse,
    });
    await chatbotMessage.save();

    res.json({ success: true, response: botResponse });
  } catch (error) {
    console.error('Error generating response:', error);
    res.status(500).json({ success: false, message: 'Error generating response' });
  }
});

//Register Streak creations
app.post("/api/streak", async (req, res) => {
  const { email, type } = req.body;

  try {
    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user) {
      return res.status(404).json({ status: 404, message: "User not found" });
    }

    const userStreak = await Streaker.findOne({ _id: user.streakId });
    if (!userStreak) {
      return res
        .status(404)
        .json({ status: 404, message: "Streak data not found" });
    }

    if (type === "CreateCourse") {
      userStreak.courseDo = true;
    } else if (type === "CreateQuiz") {
      userStreak.quizDo = true;
    } else {
      return res.status(400).json({ status: 400, message: "Invalid type!" });
    }

    await userStreak.save();

    res
      .status(200)
      .json({ status: 200, message: "Streak updated successfully!" });
  } catch (error) {
    console.error("Error updating streak:", error);
    res
      .status(500)
      .json({ status: 500, message: "Error updating streak", error });
  }
});

//streak notification
app.post("/api/NotificationStreakCheck", async (req, res) => {
  const { email, type } = req.body;
  try {
    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    const streak = await Streaker.findById(user.streakId);
    if (!streak) {
      return res.status(404).json({ message: "Streak data not found" });
    }

    // Check streak and notifications
    if (type === "check") {
      const courseNotifyStatus = streak.courseNotify;
      const quizNotifyStatus = streak.quizNotify;
      const signQuizNotifyStatus = streak.signQuizNotify;
      const signTeacherNotifyStatus = streak.signTeacherNotify;
      const quizStreakCount = streak.quizStreakCount;
      const teacherStreakCount = streak.teacherStreakCount;

      return res.status(200).json({
        courseNotifyStatus,
        quizNotifyStatus,
        signQuizNotifyStatus,
        signTeacherNotifyStatus,
        quizStreakCount,
        teacherStreakCount,
      });
    }

    // Register for teacher sign-in streak
    else if (type === "registerSignTeacher") {
      streak.signTeacher = true;
      streak.signTeacherNotify = true;
      streak.dateStrekingCourse = new Date();
      await streak.save();
      return res.status(200).json({
        message: "Teacher sign-in streak registered",
        teacherStreakCount: streak.teacherStreakCount,
      });
    }

    // Register for Quiz sign-in streak
    else if (type === "registerSignQuiz") {
      streak.signQuiz = true;
      streak.signQuizNotify = true;
      streak.dateStrekingQuiz = new Date();
      await streak.save();
      return res.status(200).json({
        message: "Quiz sign-in streak registered",
        quizStreakCount: streak.quizStreakCount,
      });
    } else if (type === "registerCreateCourse") {
      streak.courseDo = true;
      streak.courseNotify = true;
      await streak.save();
      return res.status(200).json({
        message: "Course creation streak registered",
        teacherStreakCount: streak.teacherStreakCount,
      });
    } else if (type === "registerCreateQuiz") {
      streak.quizDo = true;
      streak.quizNotify = true;
      await streak.save();
      return res.status(200).json({
        message: "Quiz creation streak registered",
        quizStreakCount: streak.quizStreakCount,
      });
    } else {
      return res.status(400).json({ message: "Invalid type provided" });
    }
  } catch (error) {
    console.error("Error fetching streak data:", error);
    return res.status(500).json({ message: "Server error" });
  }
});

// Upload PDF feature
app.post('/api/upload', upload.single('file'), async (req, res) => {
  try {
    const file = req.file;

    if (!file) {
      return res.status(400).json({ message: 'No file uploaded' });
    }

    let text = '';

    switch (file.mimetype) {
      case 'application/pdf':
        text = await parsePDF(file.buffer);
        break;
      case 'application/vnd.openxmlformats-officedocument.wordprocessingml.document':
        text = await parseDOCX(file.buffer);
        break;
      default:
        if (file.mimetype.startsWith('image/')) {
          text = await parseImage(file.buffer);
        } else {
          return res.status(400).json({ message: 'Unsupported file type' });
        }
    }

    res.json({ text });
  } catch (error) {
    console.error('Error processing file upload:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

//get chart data
app.post("/api/getStreakPerUser", async (req, res) => {
  const { email, app } = req.body;

  try {
    const today = new Date();
    const startWeek = startOfWeek(today, { weekStartsOn: 0 });
    const endWeek = endOfWeek(today, { weekStartsOn: 0 });

    const query = {
      email: email,
      ...(app === "AITeacher"
        ? { dateStrekingCourse: { $gte: startWeek, $lte: endWeek } }
        : app === "AIQuiz" && {
            dateStrekingQuiz: { $gte: startWeek, $lte: endWeek },
          }),
    };

    const streakers = await Streaker.find(query);

    let streakDataByDay = {
      Sunday: { signQuiz: 0, signTeacher: 0, quizDo: 0, courseDo: 0 },
      Monday: { signQuiz: 0, signTeacher: 0, quizDo: 0, courseDo: 0 },
      Tuesday: { signQuiz: 0, signTeacher: 0, quizDo: 0, courseDo: 0 },
      Wednesday: { signQuiz: 0, signTeacher: 0, quizDo: 0, courseDo: 0 },
      Thursday: { signQuiz: 0, signTeacher: 0, quizDo: 0, courseDo: 0 },
      Friday: { signQuiz: 0, signTeacher: 0, quizDo: 0, courseDo: 0 },
      Saturday: { signQuiz: 0, signTeacher: 0, quizDo: 0, courseDo: 0 },
    };

    streakers.forEach((streaker) => {
      const dayNameTeacher = format(
        new Date(streaker.dateStrekingCourse),
        "EEEE"
      );
      const dayNameQuiz = format(new Date(streaker.dateStrekingQuiz), "EEEE");
      streakDataByDay[dayNameQuiz].signQuiz += streaker.signQuiz ? 1 : 0;
      streakDataByDay[dayNameQuiz].quizDo += streaker.quizDo ? 1 : 0;

      streakDataByDay[dayNameTeacher].signTeacher += streaker.signTeacher
        ? 1
        : 0;
      streakDataByDay[dayNameTeacher].courseDo += streaker.courseDo ? 1 : 0;
    });

    res.status(200).json({ status: 200, chartData: streakDataByDay });
  } catch (error) {
    console.error(error);
    res.status(500).json({ status: 500, message: "Server error" });
  }
});

//Update Plan
app.post("/api/quizUpdatePlan", async (req, res) => {
  const { plan, email } = req.body;

  await User.findOneAndUpdate(
    { email: email.toLowerCase() },
    { plan: plan }
  ).then((data) => {
    if (data) {
      res.json({ status: 200, message: "user plan updated" });
    } else {
      res.json({ status: 500, message: "update plan failed" });
    }
  });
});

// SIGNUP
app.post("/api/signup", async (req, res) => {
  const { email, mName, password, type, plan, refCode, app, refMail, country } =
    req.body;

  if (!email || !password || !plan || !country) {
    return res.status(400).json({
      success: false,
      message: "Email, password, and country are required.",
    });
  }

  const token = crypto.randomBytes(32).toString("hex");

  try {
    const estimate = await User.estimatedDocumentCount();
    if (estimate > 0) {
      const existingUser = await User.findOne({ email: email.toLowerCase() });
      if (existingUser) {
        return res.status(409).json({
          success: false,
          message: "User with this email already exists.",
        });
      }

      const newUser = new User({
        email: email.toLowerCase(),
        mName,
        password,
        type,
        plan,
        signUpApp: app,
        refUserMail: refMail,
        emailToken: token,
        emailTokenExpires: Date.now() + 3600000,
        country,
      });

      await newUser.save();

      const streak1 = new Streaker({
        userId: newUser._id,
        email: email.toLowerCase(),
        signQuiz: app === "AIQuiz",
        signTeacher: app === "AITeacher",
        dateStrekingCourse: app === "AITeacher" ? new Date() : null,
        dateStrekingQuiz: app === "AIQuiz" ? new Date() : null,
      });

      await streak1.save();

      await User.findByIdAndUpdate(newUser._id, { streakId: streak1._id });

      const mailOptions = {
        from: process.env.EMAIL,
        to: email,
        subject: "Email Verification",
        html: `<!DOCTYPE html> ...`,
      };

      try {
        await transporter.sendMail(mailOptions);
      } catch (error) {
        console.error("Error sending email:", error);
        return res.status(500).json({
          success: false,
          message: "Error sending email.",
        });
      }

      let Mss = "";
      if (refCode) {
        try {
          const response = await axios.post(`${partnerServer}/api/RefUser`, {
            data: { refCode, refMail, app, email },
            type: "register",
          });
          Mss = response.data.mss;
        } catch (error) {
          console.error("Error with referral system:", error);
        }
      }

      res.json({
        success: true,
        message: `Account created successfully ${Mss}`,
        userId: newUser._id,
      });
    } else {
      const newUser = new User({
        email,
        mName,
        password,
        type,
        plan,
        refUserMail: refMail,
        emailToken: token,
        emailTokenExpires: Date.now() + 3600000,
        country,
      });

      try {
        SendEmailVerification({ mName, app, token, email });
      } catch (error) {
        console.error("Error sending email verification:", error);
      }

      await newUser.save();
      const newAdmin = new Admin({ email, mName, type: "main" });
      await newAdmin.save();

      res.json({
        success: true,
        message: "Account created successfully",
        userId: newUser._id,
      });
    }
  } catch (error) {
    console.error("Internal server error:", error);
    res.status(500).json({
      success: false,
      message: "Internal server error.",
    });
  }
});

//email verification function
async function SendEmailVerification({ mName, app, token, email }) {
  const mailOptions = {
    from: process.env.EMAIL,
    to: email,
    subject: "Email Verification",
    html: `
  <!DOCTYPE html>
  <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <style>
        body {
          font-family: 'Helvetica Neue', Arial, sans-serif;
          background-color: #f5f5f5;
          margin: 0;
          padding: 0;
        }
        .email-container {
          max-width: 600px;
          margin: 40px auto;
          padding: 20px;
          background-color: #ffffff;
          border-radius: 8px;
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        .email-header {
          text-align: center;
          margin-bottom: 30px;
        }
        .email-header img {
          width: 60px;
          margin-bottom: 20px;
        }
        .email-header h1 {
          font-size: 24px;
          color: #333;
          margin: 0;
        }
        .email-body {
          font-size: 16px;
          line-height: 1.6;
          color: #555;
        }
        .email-body strong {
          color: #333;
        }
        .app-links {
          margin: 20px 0;
        }
        .app-links a {
          display: inline-block;
          margin-right: 15px;
          color: #007bff;
          text-decoration: none;
        }
        .email-cta {
          text-align: center;
          margin: 30px 0;
        }
        .email-cta a {
          padding: 12px 30px;
          background-color: #007bff;
          color: #fff;
          text-decoration: none;
          border-radius: 5px;
          font-size: 16px;
        }
        .email-footer {
          margin-top: 40px;
          font-size: 14px;
          color: #999;
          text-align: center;
        }
      </style>
    </head>
    <body>
      <div class="email-container">
        <div class="email-header">
          <img src="${logo}" alt="${name} Logo">
          <h1>Welcome to Learnrithm</h1>
        </div>
        <div class="email-body">
          <p>Hi ${mName},</p>
          <p>Welcome to the <strong>Learnrithm</strong> application! By creating this account, you now have access to all our applications:</p>
          <div class="app-links">
            <a href="${websiteURL}">AI Teacher</a>
            <a href="${quizURL}">AI Quiz</a>
            <a href="${partnerServer}">Partner Program</a>
          </div>
          <h2 style="color: #333;">Please verify your email:</h2>
          <div class="email-cta">
            <a href="${websiteURL}/verify-email?token=${token}&app=${app}&email=${email}" target="_blank">Verify Email</a>
          </div>
          <p>Best regards,<br>The ${company} Team</p>
        </div>
        <div class="email-footer">
          <p>&copy; ${new Date().getFullYear()} ${company}. All rights reserved.</p>
        </div>
      </div>
    </body>
  </html>
`,
  };

  try {
    await transporter.sendMail(mailOptions);
  } catch (error) {
    console.error("Error sending email:", error);
  }
}

// resend Email verification
app.post("/api/resendVerificationEmail", async (req, res) => {
  const { email } = req.body;

  try {
    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user) {
      return res
        .status(404)
        .json({ success: false, message: "User not found" });
    }

    const newToken = crypto.randomBytes(32).toString("hex");
    user.emailToken = newToken;
    user.emailTokenExpires = Date.now() + 3600000;
    await user.save();

    SendEmailVerification({
      mName: user.mName,
      app: user.signUpApp,
      token: newToken,
      email: user.email,
    });

    res
      .status(200)
      .json({ success: true, message: "Verification email resent" });
  } catch (error) {
    console.error("Error sending email:", error);
    res.status(500).json({ success: false, message: "Error sending email" });
  }
});

//verify email

app.post("/api/verify-email", async (req, res) => {
  const { token } = req.body;

  const user = await User.findOne({
    emailToken: token,
    emailTokenExpires: { $gt: Date.now() },
  });

  if (!user) {
    return res.json({ message: "Invalid or expired token.", status: 500 });
  }

  try {
    user.isVerified = true;
    user.emailToken = undefined;
    user.emailTokenExpires = undefined;
    const verified = await user.save();

    if (verified.isVerified) {
      let mssage;

      if (user.refUserMail) {
        try {
          await axios
            .post(`${partnerServer}/api/RefUser`, {
              type: "verifyUser",
              data: { email: user.email, app: user.signUpApp },
            })
            .then((data) => {
              if (data.data.status === 200) {
                mssage = data.data.message;
              } else {
                mssage = data.data.message;
              }
            });
        } catch (error) {
          console.log(error);
        }
      }

      res.json({
        message: `Email verified successfully! ${mssage}`,
        status: 200,
      });
    } else {
      res.json({ message: "Email not verified", status: 404 });
    }
  } catch (error) {
    console.log(error);
  }
});

// Check verification status
app.get("/api/checkVerificationStatus", async (req, res) => {
  const { email } = req.query;

  try {
    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user) {
      return res
        .status(404)
        .json({ success: false, message: "User not found" });
    }

    return res.status(200).json({ isVerified: user.isVerified });
  } catch (error) {
    console.error("Error checking verification status:", error);
    return res.status(500).json({ success: false, message: "Server error" });
  }
});

//signin proccess

app.post("/api/signin", async (req, res) => {
  const { email, signInApp } = req.body;

  try {
    const user = await User.findOne({ email: email.toLowerCase() });

    if (!user) {
      return res.json({
        success: false,
        message: "Invalid email or password.",
      });
    }

    const now = new Date();
    now.setHours(0, 0, 0, 0);
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    yesterday.setHours(0, 0, 0, 0);
    let streakUsed = await Streaker.findById(user.streakId);

    const isSameDayOrYesterday = (lastStreakDate) => {
      if (lastStreakDate === null) {
        return true;
      }
      return lastStreakDate < now;
    };

    if (streakUsed) {
      let lastStreakTeacher = null;
      let lastStreakQuiz = null;
      if (streakUsed.dateStrekingCourse) {
        lastStreakTeacher = new Date(streakUsed.dateStrekingCourse).setHours(
          0,
          0,
          0,
          0
        );
      }

      if (streakUsed.dateStrekingQuiz) {
        lastStreakQuiz = new Date(streakUsed.dateStrekingQuiz).setHours(
          0,
          0,
          0,
          0
        );
      }

      if (
        signInApp === "AITeacher" &&
        isSameDayOrYesterday(lastStreakTeacher)
      ) {
        if (lastStreakTeacher === yesterday.getTime()) {
          streakUsed.teacherStreakCount += 1;
        } else {
          streakUsed.teacherStreakCount = 1;
        }

        // Reset AI Quiz-related flags
        if (isSameDayOrYesterday(lastStreakQuiz)) {
          streakUsed.quizDo = false;
          streakUsed.signQuiz = false;
          streakUsed.quizNotify = false;
          streakUsed.signQuizNotify = false;
        }

        // Update streak data for AI Teacher
        streakUsed.dateStrekingCourse = now;
        streakUsed.signTeacherNotify = false;
        streakUsed.courseNotify = false;
        streakUsed.courseDo = false;
      }

      // Update for AI Quiz sign-in
      else if (signInApp === "AIQuiz" && isSameDayOrYesterday(lastStreakQuiz)) {
        if (lastStreakQuiz === yesterday.getTime()) {
          streakUsed.quizStreakCount += 1; // Increment streak if from yesterday
        } else {
          streakUsed.quizStreakCount = 1; // Reset streak
        }

        // Reset AI Teacher-related flags
        if (isSameDayOrYesterday(lastStreakTeacher)) {
          streakUsed.signTeacherNotify = false;
          streakUsed.courseNotify = false;
          streakUsed.courseDo = false;
          streakUsed.signTeacher = false;
        }

        // Update streak data for AI Quiz
        streakUsed.dateStrekingQuiz = now;
        streakUsed.quizDo = false;
        streakUsed.quizNotify = false;
        streakUsed.signQuizNotify = false;
      }

      await streakUsed.save(); // Save updated streak data
    } else {
      // Create new streak data if no streak exists
      const streakData = {
        userId: user._id, // Existing user's ID
        email: email.toLowerCase(),
        signQuiz: signInApp === "AIQuiz",
        signTeacher: signInApp === "AITeacher",
        teacherStreakCount: signInApp === "AITeacher" ? 1 : 0, // Start streak count at 1
        quizStreakCount: signInApp === "AIQuiz" ? 1 : 0, // Start streak count at 1
        dateStrekingQuiz: signInApp === "AIQuiz" ? now : null,
        dateStrekingCourse: signInApp === "AITeacher" ? now : null,
      };

      const newStreak = new Streaker(streakData);
      await newStreak.save();

      user.streakId = newStreak._id; // Assign streak ID to user
      await user.save(); // Save updated user
    }

    return res.json({
      success: true,
      message: "SignIn successful",
      userData: {
        _id: user._id,
        email: user.email,
        mName: user.mName,
        type: user.type,
        plan: user.plan,
      },
    });
  } catch (error) {
    // Handle server errors
    console.error(error);
    return res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
});

//SEND MAIL
app.post("/api/data", async (req, res) => {
  const receivedData = req.body;

  try {
    const emailHtml = receivedData.html;

    const options = {
      from: process.env.EMAIL,
      to: receivedData.to,
      subject: receivedData.subject,
      html: emailHtml,
    };

    const data = await transporter.sendMail(options);
    res.status(200).json(data);
  } catch (error) {
    res.status(400).json(error);
  }
});

//FOROGT PASSWORD
app.post("/api/forgot", async (req, res) => {
  const { email, name, company, logo } = req.body;

  try {
    const user = await User.findOne({ email: email.toLowerCase() });

    if (!user) {
      return res.json({ success: false, message: "User not found" });
    }

    const token = crypto.randomBytes(20).toString("hex");
    user.resetPasswordToken = token;
    user.resetPasswordExpires = Date.now() + 3600000;
    await user.save();

    const resetLink = `${process.env.WEBSITE_URL}/reset-password/${token}`;

    const mailOptions = {
      from: process.env.EMAIL,
      to: user.email,
      subject: `${name} Password Reset`,
      html: `<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
            <meta http-equiv="Content-Type" content="text/html charset=UTF-8" />
            <html lang="en">
            
              <head></head>
             <div id="__react-email-preview" style="display:none;overflow:hidden;line-height:1px;opacity:0;max-height:0;max-width:0">Password Reset<div> ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿</div>
             </div>
            
              <body style="margin-left:auto;margin-right:auto;margin-top:auto;margin-bottom:auto;background-color:rgb(255,255,255);font-family:ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;">
                <table align="center" role="presentation" cellSpacing="0" cellPadding="0" border="0" width="100%" style="max-width:37.5em;margin-left:auto;margin-right:auto;margin-top:40px;margin-bottom:40px;width:465px;border-radius:0.25rem;border-width:1px;border-style:solid;border-color:rgb(234,234,234);padding:20px">
                  <tr style="width:100%">
                    <td>
                      <table align="center" border="0" cellPadding="0" cellSpacing="0" role="presentation" width="100%" style="margin-top:32px">
                        <tbody>
                          <tr>
                            <td><img alt="Vercel" src="${logo}" width="40" height="37" style="display:block;outline:none;border:none;text-decoration:none;margin-left:auto;margin-right:auto;margin-top:0px;margin-bottom:0px" /></td>
                          </tr>
                        </tbody>
                      </table>
                      <h1 style="margin-left:0px;margin-right:0px;margin-top:30px;margin-bottom:30px;padding:0px;text-align:center;font-size:24px;font-weight:400;color:rgb(0,0,0)">Password Reset</h1>
                      <p style="font-size:14px;line-height:24px;margin:16px 0;color:rgb(0,0,0)">Click on the button below to reset the password for your account ${email}.</p>
                      <table align="center" border="0" cellPadding="0" cellSpacing="0" role="presentation" width="100%" style="margin-bottom:32px;margin-top:32px;text-align:center">
                        <tbody>
                          <tr>
                            <td><a href="${resetLink}" target="_blank" style="p-x:20px;p-y:12px;line-height:100%;text-decoration:none;display:inline-block;max-width:100%;padding:12px 20px;border-radius:0.25rem;background-color:rgb(0,0,0);text-align:center;font-size:12px;font-weight:600;color:rgb(255,255,255);text-decoration-line:none"><span></span><span style="p-x:20px;p-y:12px;max-width:100%;display:inline-block;line-height:120%;text-decoration:none;text-transform:none;mso-padding-alt:0px;mso-text-raise:9px"</span><span>Reset</span></a></td>
                          </tr>
                        </tbody>
                      </table>
                      <p style="font-size:14px;line-height:24px;margin:16px 0;color:rgb(0,0,0)">Best,<p target="_blank" style="color:rgb(0,0,0);text-decoration:none;text-decoration-line:none">The <strong>${company}</strong> Team</p></p>
                      </td>
                  </tr>
                </table>
              </body>
            
            </html>`,
    };

    await transporter.sendMail(mailOptions);

    res.json({
      success: true,
      message: "Password reset link sent to your email",
    });
  } catch (error) {
    res.status(500).json({ success: false, message: "I am the problem" });
  }
});

//FOROGT PASSWORD
app.post("/api/reset-password", async (req, res) => {
  const { password, token } = req.body;

  try {
    const user = await User.findOne({
      resetPasswordToken: token,
      resetPasswordExpires: { $gt: Date.now() },
    });

    if (!user) {
      return res.json({ success: true, message: "Invalid or expired token" });
    }

    user.password = password;
    user.resetPasswordToken = null;
    user.resetPasswordExpires = null;

    await user.save();

    res.json({
      success: true,
      message: "Password updated successfully",
      email: user.email,
    });

    axios.post("https://quiz.learnrithm.com/api/sycn", {
      password,
      email: user.email,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: "Internal server error" });
  }
});

//Check generation validity
app.post("/api/valid", async (req, res) => {
  const { user } = req.body;

  try {
    const countResult = await Course.aggregate([
      { $match: { user } },
      { $count: "totalCourses" },
    ]);

    const totalCourses =
      countResult.length > 0 ? countResult[0].totalCourses : 0;
    if (totalCourses >= 5) {
      res.status(200).json({ message: "not valid" });
    } else {
      res.status(200).json({ message: "valid" });
    }
  } catch (error) {
    res.status(500).json({ message: `Internal Server Erro ${error}` });
  }
});

//GET DATA FROM MODEL
app.post("/api/prompt", async (req, res) => {
  const { prompt } = req.body;
  if (!prompt) {
    return res
      .status(400)
      .json({ success: false, message: "Prompt is required" });
  }

  const safetySettings = [
    {
      category: HarmCategory.HARM_CATEGORY_HARASSMENT,
      threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
    },
    {
      category: HarmCategory.HARM_CATEGORY_HATE_SPEECH,
      threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
    },
    {
      category: HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT,
      threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
    },
    {
      category: HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT,
      threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
    },
  ];

  const model = genAI.getGenerativeModel({
    model: "gemini-1.0-pro",
    safetySettings,
  });

  try {
    const result = await model.generateContent(prompt);
    const response = result.response;
    const generatedText = response.text();
    res.status(200).json({ success: true, generatedText });
  } catch (error) {
    console.error("Error generating content:", error);
    res.status(500).json({
      success: false,
      message: `Internal server error: ${error.message}`,
    });
  }
});

//GET GENERATE THEORY
app.post("/api/generate", async (req, res) => {
  const receivedData = req.body;

  const promptString = receivedData.prompt;

  const safetySettings = [
    {
      category: HarmCategory.HARM_CATEGORY_HARASSMENT,
      threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
    },
    {
      category: HarmCategory.HARM_CATEGORY_HATE_SPEECH,
      threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
    },
    {
      category: HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT,
      threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
    },
    {
      category: HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT,
      threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
    },
  ];

  const model = genAI.getGenerativeModel({
    model: "gemini-1.0-pro",
    safetySettings,
  });

  const prompt = promptString;

  await model
    .generateContent(prompt)
    .then((result) => {
      const response = result.response;
      const txt = response.text();
      const converter = new showdown.Converter();
      const markdownText = txt;
      const text = converter.makeHtml(markdownText);
      res.status(200).json({ text });
    })
    .catch((error) => {
      console.log(error);
      res.status(500).json({ success: false, message: "I am the problem " });
    });
});

app.get("/api/leaderboard", async (req, res) => {
  try {
    // Fetch all users sorted by streak in descending order
    const users = await User.find().sort({ streak: -1 }).select("mName streak");

    return res.json({
      success: true,
      data: users,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: "Internal Server Error" });
  }
});

//GET IMAGE
app.post("/api/image", async (req, res) => {
  const receivedData = req.body;
  const promptString = receivedData.prompt;
  gis(promptString, logResults);
  function logResults(error, results) {
    if (error) {
      //ERROR
    } else {
      res.status(200).json({ url: results[0].url });
    }
  }
});

//GET VIDEO
app.post("/api/yt", async (req, res) => {
  try {
    const receivedData = req.body;
    const promptString = receivedData.prompt;
    const video = await youtubesearchapi.GetListByKeyword(
      promptString,
      [false],
      [1],
      [{ type: "video" }]
    );
    const videoId = await video.items[0].id;
    res.status(200).json({ url: videoId });
  } catch (error) {
    res.status(500).json({ success: false, message: "Internal server error" });
  }
});

//GET TRANSCRIPT
app.post("/api/transcript", async (req, res) => {
  const receivedData = req.body;
  const promptString = receivedData.prompt;
  YoutubeTranscript.fetchTranscript(promptString)
    .then((video) => {
      res.status(200).json({ url: video });
    })
    .catch((error) => {
      res
        .status(500)
        .json({ success: false, message: "Internal server error" });
    });
});

//STORE COURSE
app.post("/api/course", async (req, res) => {
  const { user, content, type, mainTopic, language, email } = req.body;

  unsplash.search
    .getPhotos({
      query: mainTopic,
      page: 1,
      perPage: 1,
      orientation: "landscape",
    })
    .then(async (result) => {
      const photos = result.response.results;
      const photo = photos[0].urls.regular;
      try {
        const newCourse = new Course({
          email,
          user,
          content,
          type,
          mainTopic,
          photo,
          language,
        });
        await newCourse.save();

        return res.json({
          success: true,
          message: "Course created successfully",
          courseId: newCourse._id,
        });
      } catch (error) {
        console.log(error);
        return res
          .status(500)
          .json({ success: false, message: "Internal server error" });
      }
    });
});
//UPDATE COURSE
app.post("/api/update", async (req, res) => {
  const { content, courseId } = req.body;
  try {
    await Course.findOneAndUpdate({ _id: courseId }, [
      { $set: { content: content } },
    ])
      .then(() => {
        res.json({ success: true, message: "Course updated successfully" });
      })
      .catch(() => {
        res
          .status(500)
          .json({ success: false, message: "Internal server error" });
      });
  } catch (error) {
    res.status(500).json({ success: false, message: "Internal server error" });
  }
});

app.post("/api/finish", async (req, res) => {
  const { courseId } = req.body;
  try {
    await Course.findOneAndUpdate(
      { _id: courseId },
      { $set: { completed: true, end: Date.now() } }
    )
      .then(() => {
        res.json({ success: true, message: "Course completed successfully" });
      })
      .catch(() => {
        res
          .status(500)
          .json({ success: false, message: "Internal server error" });
      });
  } catch (error) {
    res.status(500).json({ success: false, message: "Internal server error" });
  }
});

//SEND CERTIFICATE
app.post("/api/sendcertificate", async (req, res) => {
  const { html, email } = req.body;

  const transporter = nodemailer.createTransport({
    host: "smtp.gmail.com",
    port: 465,
    service: "gmail",
    secure: true,
    auth: {
      user: process.env.EMAIL,
      pass: process.env.PASSWORD,
    },
  });

  const options = {
    from: process.env.EMAIL,
    to: email,
    subject: "Certification of completion",
    html: html,
  };

  transporter.sendMail(options, (error) => {
    if (error) {
      res.status(500).json({ success: false, message: "Failed to send email" });
    } else {
      res.json({ success: true, message: "Email sent successfully" });
    }
  });
});

//GET ALL COURSES
app.post("/api/courses", async (req, res) => {
  const { user } = req.body;

  try {
    await Course.find({ user: user }).then((result) => {
      res.json({ status: 200, courses: result });
    });
  } catch (error) {
    console.log(error);
    res.status(500).send("Internal Server Error");
  }
});

//detect course language
app.post("/api/getlanguage", async (req, res) => {
  const { courseId } = req.body;
  try {
    const course = await Course.find({ _id: courseId });
    if (course) {
      res.status(200).json({ language: course.language });
    } else {
      res.status(404).json({ message: "Course not found (404)" });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

//GET PROFILE DETAILS
app.post("/api/profile", async (req, res) => {
  const { email, mName, password, uid } = req.body;
  try {
    if (password === "") {
      await User.findOneAndUpdate(
        { _id: uid },
        { $set: { email: email, mName: mName } }
      )
        .then(() => {
          res.json({ success: true, message: "Profile Updated" });
        })
        .catch(() => {
          res
            .status(500)
            .json({ success: false, message: "Internal server error" });
        });
    } else {
      await User.findOneAndUpdate(
        { _id: uid },
        { $set: { email: email, mName: mName, password: password } }
      )
        .then(() => {
          res.json({ success: true, message: "Profile Updated" });
        })
        .catch(() => {
          res
            .status(500)
            .json({ success: false, message: "Internal server error" });
        });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: "Internal server error" });
  }
});

//GET SUBSCRIPTION DETAILS
app.post("/api/subscriptiondetail", async (req, res) => {
  try {
    const { uid } = req.body;

    const userDetails = await Subscription.findOne({ user: uid });
    if (userDetails.method === "paystack") {
      const authorization = `Bearer ${process.env.PAYSTACK_SECRET_KEY}`;
      const response = await axios.get(
        `https://api.paystack.co/subscription/${userDetails.subscriberId}`,
        {
          headers: {
            Authorization: authorization,
          },
        }
      );

      let subscriptionDetails = null;
      subscriptionDetails = {
        subscription_code: response.data.data.subscription_code,
        createdAt: response.data.data.createdAt,
        updatedAt: response.data.data.updatedAt,
        customer_code: userDetails.subscription,
        email_token: response.data.data.email_token,
      };

      res.json({ session: subscriptionDetails, method: userDetails.method });
    }
  } catch (error) {
    //DO NOTHING
  }
});

//DOWNLOAD RECEIPT
app.post("/api/downloadreceipt", async (req, res) => {
  const { html, email } = req.body;

  const transporter = nodemailer.createTransport({
    host: "smtp.gmail.com",
    port: 465,
    service: "gmail",
    secure: true,
    auth: {
      user: process.env.EMAIL,
      pass: process.env.PASSWORD,
    },
  });

  const options = {
    from: process.env.EMAIL,
    to: email,
    subject: "Subscription Receipt",
    html: html,
  };

  transporter.sendMail(options, (error, info) => {
    if (error) {
      res
        .status(500)
        .json({ success: false, message: "Failed to send receipt" });
    } else {
      res.json({ success: true, message: "Receipt sent to your mail" });
    }
  });
});

//SEND RECEIPT
app.post("/api/sendreceipt", async (req, res) => {
  const { html, email, plan, subscriberId, user, method, subscription } =
    req.body;

  const existingSubscription = await Subscription.findOne({ user: user });
  if (existingSubscription) {
    //DO NOTHING
  } else {
    const newSub = new Subscription({
      user,
      subscription,
      subscriberId,
      plan,
      method,
    });
    await newSub.save();
  }

  const transporter = nodemailer.createTransport({
    host: "smtp.gmail.com",
    port: 465,
    service: "gmail",
    secure: true,
    auth: {
      user: process.env.EMAIL,
      pass: process.env.PASSWORD,
    },
  });

  const options = {
    from: process.env.EMAIL,
    to: email,
    subject: "Subscription Receipt",
    html: html,
  };

  transporter.sendMail(options, (error, info) => {
    if (error) {
      res
        .status(500)
        .json({ success: false, message: "Failed to send receipt" });
    } else {
      res.json({ success: true, message: "Receipt sent to your mail" });
    }
  });
});

//CONTACT
app.post("/api/contact", async (req, res) => {
  const { fname, lname, email, phone, msg } = req.body;
  try {
    const newContact = new Contact({ fname, lname, email, phone, msg });
    await newContact.save();
    res.json({ success: true, message: "Submitted" });
  } catch (error) {
    res.status(500).json({ success: false, message: "Internal server error" });
  }
});

//DASHBOARD
app.post("/api/dashboard", async (req, res) => {
  const users = await User.estimatedDocumentCount();
  const courses = await Course.estimatedDocumentCount();
  const admin = await Admin.findOne({ type: "main" });
  const total = admin.total;
  const monthlyPlanCount = await User.countDocuments({
    type: process.env.MONTH_TYPE,
  });
  const yearlyPlanCount = await User.countDocuments({
    type: process.env.YEAR_TYPE,
  });
  let monthCost = monthlyPlanCount * process.env.MONTH_COST;
  let yearCost = yearlyPlanCount * process.env.YEAR_COST;
  let sum = monthCost + yearCost;
  let paid = yearlyPlanCount + monthlyPlanCount;
  const videoType = await Course.countDocuments({
    type: "video & text course",
  });
  const textType = await Course.countDocuments({
    type: "theory & image course",
  });
  let free = users - paid;
  res.json({
    users: users,
    courses: courses,
    total: total,
    sum: sum,
    paid: paid,
    videoType: videoType,
    textType: textType,
    free: free,
    admin: admin,
  });
});

//GET USERS
app.get("/api/getusers", async (req, res) => {
  try {
    const users = await User.find({});
    res.json(users);
  } catch (error) {
    //DO NOTHING
  }
});

//GET COURES
app.get("/api/getcourses", async (req, res) => {
  try {
    const courses = await Course.find({});
    res.json(courses);
  } catch (error) {
    //DO NOTHING
  }
});

//GET PAID USERS
app.get("/api/getpaid", async (req, res) => {
  try {
    const paidUsers = await User.find({ type: { $ne: "free" } });
    res.json(paidUsers);
  } catch (error) {
    //DO NOTHING
  }
});

//GET ADMINS
app.get("/api/getadmins", async (req, res) => {
  try {
    const users = await User.find({
      email: { $nin: await getEmailsOfAdmins() },
    });
    const admins = await Admin.find({});
    res.json({ users: users, admins: admins });
  } catch (error) {
    //DO NOTHING
  }
});

async function getEmailsOfAdmins() {
  const admins = await Admin.find({});
  return admins.map((admin) => admin.email);
}

//ADD ADMIN
app.post("/api/addadmin", async (req, res) => {
  const { email } = req.body;
  try {
    const user = await User.findOne({ email: email });
    const newAdmin = new Admin({
      email: user.email,
      mName: user.mName,
      type: "no",
    });
    await newAdmin.save();
    res.json({ success: true, message: "Admin added successfully" });
  } catch (error) {
    //DO NOTHING
  }
});

//REMOVE ADMIN
app.post("/api/removeadmin", async (req, res) => {
  const { email } = req.body;
  try {
    await Admin.findOneAndDelete({ email: email });
    res.json({ success: true, message: "Admin removed successfully" });
  } catch (error) {
    //DO NOTHING
  }
});

//GET CONTACTS
app.get("/api/getcontact", async (req, res) => {
  try {
    const contacts = await Contact.find({});
    res.json(contacts);
  } catch (error) {
    //DO NOTHING
  }
});

//SAVE ADMIN
app.post("/api/saveadmin", async (req, res) => {
  const { data, type } = req.body;
  try {
    if (type === "terms") {
      await Admin.findOneAndUpdate(
        { type: "main" },
        { $set: { terms: data } }
      ).then((rl) => {
        res.json({ success: true, message: "Saved successfully" });
      });
    } else if (type === "privacy") {
      await Admin.findOneAndUpdate(
        { type: "main" },
        { $set: { privacy: data } }
      ).then((rl) => {
        res.json({ success: true, message: "Saved successfully" });
      });
    } else if (type === "cancel") {
      await Admin.findOneAndUpdate(
        { type: "main" },
        { $set: { cancel: data } }
      ).then((rl) => {
        res.json({ success: true, message: "Saved successfully" });
      });
    } else if (type === "refund") {
      await Admin.findOneAndUpdate(
        { type: "main" },
        { $set: { refund: data } }
      ).then((rl) => {
        res.json({ success: true, message: "Saved successfully" });
      });
    } else if (type === "billing") {
      await Admin.findOneAndUpdate(
        { type: "main" },
        { $set: { billing: data } }
      ).then((rl) => {
        res.json({ success: true, message: "Saved successfully" });
      });
    }
  } catch (error) {
    //DO NOTHING
  }
});

//GET POLICIES
app.get("/api/policies", async (req, res) => {
  try {
    const admins = await Admin.find({});
    res.json(admins);
  } catch (error) {
    //DO NOTHING
  }
});

// PAYSTACK PAYMENT
app.post("/api/paystackpayment", async (req, res) => {
  const { planId, amountInZar, email, orderId } = req.body;

  try {
    const data = {
      email,
      amount: amountInZar * 100, // Paystack expects amount in kobo
      plan: planId,
      reference: orderId,
      callback_url: `${serverURL}/success`,
    };

    const response = await axios.post(
      "https://api.paystack.co/transaction/initialize",
      data,
      {
        headers: {
          Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}`,
          "Content-Type": "application/json",
        },
      }
    );

    res.json(response.data);
  } catch (error) {
    console.error('Paystack payment initialization error:', error.response ? error.response.data : error.message);
    res.status(500).json({ error: error.response ? error.response.data : 'Internal Server Error' });
  }
});

//PAYSTACK GET DETAIL
app.post("/api/paystackfetch", async (req, res) => {
  const { email, uid, plan } = req.body;
  try {
    const searchEmail = email;
    const url = "https://api.paystack.co/subscription";
    const authorization = `Bearer ${process.env.PAYSTACK_SECRET_KEY}`;

    axios
      .get(url, {
        headers: {
          Authorization: authorization,
        },
      })
      .then(async (response) => {
        const jsonData = response.data;
        let subscriptionDetails = null;
        jsonData.data.forEach((subscription) => {
          if (subscription.customer.email === searchEmail) {
            subscriptionDetails = {
              subscription_code: subscription.subscription_code,
              createdAt: subscription.createdAt,
              updatedAt: subscription.updatedAt,
              customer_code: subscription.customer.customer_code,
            };
          }
        });

        if (subscriptionDetails) {
          let cost = 0;
          if (plan === process.env.MONTH_TYPE) {
            cost = process.env.MONTH_COST;
          } else {
            cost = process.env.YEAR_COST;
          }
          cost = cost / 4;

          await Admin.findOneAndUpdate(
            { type: "main" },
            { $inc: { total: cost } }
          );

          await User.findOneAndUpdate({ _id: uid }, { $set: { type: plan } })
            .then(async (result) => {
              res.json({ details: subscriptionDetails });
            })
            .catch((error) => {
              res
                .status(500)
                .json({ success: false, message: "Internal server error" });
            });
        } else {
          res.status(500).json({ error: "Internal Server Error" });
        }
      })
      .catch((error) => {
        res.status(500).json({ error: "Internal Server Error" });
      });
  } catch (e) {
    res.status(500).json({ error: "Internal Server Error" });
  }
});

//success Register Paystack

app.post("/api/register", async (req, res) => {
  const { email, plan, method } = req.body;

  try {
    const searchEmail = email;
    const url = "https://api.paystack.co/subscription";
    const authorization = `Bearer ${process.env.PAYSTACK_SECRET_KEY}`;
    let subscriptionDetails;

    // Using async/await for axios
    const response = await axios.get(url, {
      headers: {
        Authorization: authorization,
      },
    });

    const jsonData = response.data;
    jsonData.data.forEach((subscription) => {
      if (subscription.customer.email === searchEmail) {
        subscriptionDetails = {
          subscription_code: subscription.subscription_code,
          createdAt: subscription.createdAt,
          customer_code: subscription.customer.customer_code,
        };
      }
    });

    if (!subscriptionDetails) {
      return res
        .status(400)
        .json({ error: "Subscription not found for this email." });
    }

    // Fetch subscription info
    let subscribed = await Subscription.findOne({ user: email });

    if (!subscribed) {
      const user = email;
      const date = new Date();
      const active = "true";
      const subscription = subscriptionDetails.subscription_code;
      const subscriberId = subscriptionDetails.customer_code;

      const subs = new Subscription({
        user,
        subscription,
        subscriberId,
        plan,
        method,
        date,
        active,
      });
      await subs.save();

      await User.findOneAndUpdate(
        { email }, // filter
        { type: plan }, // update
        { new: true } // options: return the updated document
      );

      const userAuth = await User.findOne({ email: email });

      if (!userAuth) {
        return res.status(400).json({ error: "User not authenticated." });
      }

      try {
        await axios.post(`${partnerServer}/api/RefUser`, {
          type: "registerPayment",
          data: {
            plan:
              plan === "Monthly Plan"
                ? "Monthly"
                : plan === "Yearly Plan" && "Yearly",
            email,
            app: "AITeacher",
          },
        });
      } catch (error) {
        console.log(error);
      }
    } else {
      const date = new Date();
      let expiredDate;

      if (plan === "Monthly Plan") {
        expiredDate = new Date(date.setMonth(date.getMonth() + 1));
      } else if (plan === "Yearly Plan") {
        expiredDate = new Date(date.setFullYear(date.getFullYear() + 1));
      }

      // Update existing subscription
      subscribed.plan = plan;
      subscribed.method = method;
      subscribed.date = Date.now();
      subscribed.active = isActiveSubscription(expiredDate);
      subscribed.subscription = subscriptionDetails.subscription_code;
      subscribed.subscriberId = subscriptionDetails.customer_code;
      await subscribed.save();

      await User.findOneAndUpdate(
        { email }, // filter
        { type: plan }, // update
        { new: true } // options: return the updated document
      );
    }

    res.status(200).json({ message: "Subscription handled successfully" });
  } catch (error) {
    console.log(error);
    res
      .status(500)
      .json({ error: "An error occurred while handling the subscription." });
  }
});

//PAYSTACK PAYMENT
app.post("/api/paystackcancel", async (req, res) => {
  const { code, token, email } = req.body;

  const url = "https://api.paystack.co/subscription/disable";
  const authorization = `Bearer ${process.env.PAYSTACK_SECRET_KEY}`;
  const contentType = "application/json";
  const data = {
    code: code,
    token: token,
  };

  axios
    .post(url, data, {
      headers: {
        Authorization: authorization,
        "Content-Type": contentType,
      },
    })
    .then(async (response) => {
      const subscriptionDetails = await Subscription.findOne({
        subscriberId: code,
      });
      const userId = subscriptionDetails.user;

      await User.findOneAndUpdate({ _id: userId }, { $set: { type: "free" } });

      const userDetails = await User.findOne({ _id: userId });
      await Subscription.findOneAndDelete({ subscriberId: code });

      const transporter = nodemailer.createTransport({
        host: "smtp.gmail.com",
        port: 465,
        service: "gmail",
        secure: true,
        auth: {
          user: process.env.EMAIL,
          pass: process.env.PASSWORD,
        },
      });

      const Reactivate = process.env.WEBSITE_URL + "/pricing";

      const mailOptions = {
        from: process.env.EMAIL,
        to: email,
        subject: `${userDetails.mName} Your Subscription Plan Has Been Cancelled`,
        html: `<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
                <meta http-equiv="Content-Type" content="text/html charset=UTF-8" />
                <html lang="en">
                
                  <head></head>
                 <div id="__react-email-preview" style="display:none;overflow:hidden;line-height:1px;opacity:0;max-height:0;max-width:0">Subscription Cancelled<div> ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿</div>
                 </div>
                
                  <body style="margin-left:auto;margin-right:auto;margin-top:auto;margin-bottom:auto;background-color:rgb(255,255,255);font-family:ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, &quot;Noto Sans&quot;, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;">
                    <table align="center" role="presentation" cellSpacing="0" cellPadding="0" border="0" width="100%" style="max-width:37.5em;margin-left:auto;margin-right:auto;margin-top:40px;margin-bottom:40px;width:465px;border-radius:0.25rem;border-width:1px;border-style:solid;border-color:rgb(234,234,234);padding:20px">
                      <tr style="width:100%">
                        <td>
                          <table align="center" border="0" cellPadding="0" cellSpacing="0" role="presentation" width="100%" style="margin-top:32px">
                            <tbody>
                              <tr>
                                <td><img alt="Vercel" src="${process.env.LOGO}" width="40" height="37" style="display:block;outline:none;border:none;text-decoration:none;margin-left:auto;margin-right:auto;margin-top:0px;margin-bottom:0px" /></td>
                              </tr>
                            </tbody>
                          </table>
                          <h1 style="margin-left:0px;margin-right:0px;margin-top:30px;margin-bottom:30px;padding:0px;text-align:center;font-size:24px;font-weight:400;color:rgb(0,0,0)">Subscription Cancelled</h1>
                          <p style="font-size:14px;line-height:24px;margin:16px 0;color:rgb(0,0,0)">${userDetails.mName}, your subscription plan has been Cancelled. Reactivate your plan by clicking on the button below.</p>
                          <table align="center" border="0" cellPadding="0" cellSpacing="0" role="presentation" width="100%" style="margin-bottom:32px;margin-top:32px;text-align:center">
                               <tbody>
                                  <tr>
                                    <td><a href="${Reactivate}" target="_blank" style="p-x:20px;p-y:12px;line-height:100%;text-decoration:none;display:inline-block;max-width:100%;padding:12px 20px;border-radius:0.25rem;background-color:rgb(0,0,0);text-align:center;font-size:12px;font-weight:600;color:rgb(255,255,255);text-decoration-line:none"><span></span><span style="p-x:20px;p-y:12px;max-width:100%;display:inline-block;line-height:120%;text-decoration:none;text-transform:none;mso-padding-alt:0px;mso-text-raise:9px"</span><span>Reactivate</span></a></td>
                                  </tr>
                                </tbody>
                          </table>
                          <p style="font-size:14px;line-height:24px;margin:16px 0;color:rgb(0,0,0)">Best,<p target="_blank" style="color:rgb(0,0,0);text-decoration:none;text-decoration-line:none">The <strong>${process.env.COMPANY}</strong> Team</p></p>
                          </td>
                      </tr>
                    </table>
                  </body>
                
                </html>`,
      };

      await transporter.sendMail(mailOptions);
      res.json({ success: true, message: "" });
    });
});

//CHAT
// Find the chat API endpoint and update the model name

app.post("/api/chat", async (req, res) => {
  const receivedData = req.body;
  const promptString = receivedData.prompt;

  const safetySettings = [
    {
      category: HarmCategory.HARM_CATEGORY_HARASSMENT,
      threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
    },
    {
      category: HarmCategory.HARM_CATEGORY_HATE_SPEECH,
      threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
    },
    {
      category: HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT,
      threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
    },
    {
      category: HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT,
      threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
    },
  ];

  // Update model name from "gemini-1.0-pro" to "gemini-pro"
  const model = genAI.getGenerativeModel({
    model: "gemini-pro",
    safetySettings,
  });

  const prompt = promptString;

  await model
    .generateContent(prompt)
    .then((result) => {
      const response = result.response;
      const txt = response.text();
      const converter = new showdown.Converter();
      const markdownText = txt;
      const text = converter.makeHtml(markdownText);
      res.status(200).json({ text });
    })
    .catch((error) => {
      console.error("Error generating content:", error);
      res
        .status(500)
        .json({ success: false, message: "Internal server error" });
    });
});

//Fetch Payment Method
app.post("/api/fetchPaymentMethod", async (req, res) => {
  const { email } = req.body;

  let subscribed = await Subscription.findOne({ user: email });

  if (!subscribed) {
    res.status(404).json({ error: "Subscription not found" });
  } else {
    res.status(200).json({ method: subscribed.method });
  }
});

// Utility function to check if the subscription is active
const isActiveSubscription = (expiredDate) => {
  const currentDate = new Date();
  return currentDate < new Date(expiredDate);
};

// Flutterwave Handler
app.post("/api/flutterwavePaymentHandel", async (req, res) => {
  try {
    const { email, plan, method, flwId, tx_ref } = req.body; // Extract from request body

    // Fetch subscription info
    let subscribed = await Subscription.findOne({ user: email });

    // Expired date manip

    if (!subscribed) {
      const user = email;
      const date = new Date();

      const active = "true";
      const subscription = flwId;
      const subscriberId = tx_ref;

      const subs = new Subscription({
        user,
        subscription,
        subscriberId,
        plan,
        method,
        date,
        active,
      });
      await subs.save();

      await User.findOneAndUpdate(
        { email }, // filter
        { type: plan }, // update
        { new: true } // options: return the updated document
      );

      const userAuth = await User.findOne({ email: email });

      if (!userAuth) {
        return;
      }

      try {
        await axios.post(`${partnerServer}/api/RefUser`, {
          type: "registerPayment",
          data: {
            plan:
              plan === "Monthly Plan"
                ? "Monthly"
                : plan === "Yearly Plan" && "Yearly",
            email,
            app: "AITeacher",
          },
        });
      } catch (error) {
        console.log(error);
      }
    } else {
      const date = new Date();
      let expiredDate;

      if (plan === "Monthly Plan") {
        expiredDate = new Date(date.setMonth(date.getMonth() + 1));
      } else if (plan === "Yearly Plan") {
        expiredDate = new Date(date.setFullYear(date.getFullYear() + 1));
      }

      // Update existing subscription
      subscribed.plan = plan;
      subscribed.method = method;
      subscribed.date = Date.now();
      subscribed.active = isActiveSubscription(expiredDate);
      subscribed.subscription = flwId;
      subscribed.subscriberId = tx_ref;
      await subscribed.save();
      await User.findOneAndUpdate(
        { email }, // filter
        { type: plan }, // update
        { new: true } // options: return the updated document
      );
    }
    res.status(200).json({ message: "Subscription handled successfully" });
  } catch (error) {
    res
      .status(500)
      .json({ error: "An error occurred while handling the subscription" });
  }
});

// Utility Functions

function calculateExpiredDate(creationDate, planType) {
  const expiredDate = new Date(creationDate);
  if (planType === "Monthly Plan") {
    expiredDate.setMonth(expiredDate.getMonth() + 1);
  } else if (planType === "Yearly Plan") {
    expiredDate.setFullYear(expiredDate.getFullYear() + 1);
  }
  return expiredDate;
}

async function handleExpiredSubscription(userInfo, email) {
  await Subscription.deleteOne({ user: email });
  userInfo.type = "free";
  await userInfo.save();
}

function findPlanType(subscriptionPlan) {
  // Assume 67117 is the Monthly Plan, all others are Yearly
  return subscriptionPlan === 67117 ? "Monthly Plan" : "Yearly Plan";
}

app.post("/api/expiredPaymentValidation", async (req, res) => {
  try {
    const { email } = req.body;

    // Find subscription and user info from your database
    let subscribed = await Subscription.findOne({ user: email });
    let userInfo = await User.findOne({ email });

    if (!subscribed) {
      return res.json({
        expired: false,
        message: "No subscription found for user",
      });
    }

    if (!userInfo) {
      return res.status(404).json({ message: "User not found" });
    }

    // Flutterwave Subscription Validation
    if (subscribed.method === "flutterwave") {
      const allSubscriptions = await flw.Subscription.fetch_all();
      const userSubscriptions = allSubscriptions.data.filter(
        (subscription) => subscription.customer.customer_email === email
      );

      if (userSubscriptions.length === 0) {
        return res.json({ expired: false, message: "No subscriptions found" });
      }

      userSubscriptions.sort(
        (a, b) => new Date(b.created_at) - new Date(a.created_at)
      );

      const latestSubscription = userSubscriptions[0];
      const plan = findPlanType(latestSubscription.plan);
      const creationDate = new Date(latestSubscription.created_at);
      const expiredDate = calculateExpiredDate(creationDate, plan);

      const isExpired =
        latestSubscription.status !== "active" || new Date() > expiredDate;

      res.json({ expired: isExpired, expiredDate });

      if (isExpired) {
        await handleExpiredSubscription(userInfo, email);
      }
    }
    // Paystack Subscription Validation
    else if (subscribed.method === "paystack") {
      const url = "https://api.paystack.co/subscription";
      const authorization = `Bearer ${process.env.PAYSTACK_SECRET_KEY}`;

      const response = await axios.get(url, {
        headers: {
          Authorization: authorization,
        },
      });

      const jsonData = response.data;
      const subscriptionDetails = jsonData.data.find(
        (subscription) => subscription.customer.email === email
      );

      if (!subscriptionDetails) {
        return res.json({ expired: false, message: "No subscription found" });
      }

      const creationDate = new Date(subscriptionDetails.createdAt);
      const planType =
        subscribed.type === "Yearly Plan" ? "Yearly Plan" : "Monthly Plan";
      const expiredDate = calculateExpiredDate(creationDate, planType);
      const isExpired = new Date() > expiredDate;

      res.json({ expired: isExpired, expiredDate });

      if (isExpired) {
        await handleExpiredSubscription(userInfo, email);

        // Optionally, cancel subscription on Paystack
        await axios.post(
          `https://api.paystack.co/subscription/${subscriptionDetails.subscription_code}/disable`,
          {},
          {
            headers: {
              Authorization: authorization,
            },
          }
        );
      }
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error", error });
  }
});

// Serve static files from the React app
app.use(express.static(path.join(__dirname, "../build")));

// The "catchall" handler: for any request that doesn't match one above, send back the React app
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "../build", "index.html"));
});
app.use(bodyParser.json({ limit: '50mb' }));
app.use(bodyParser.urlencoded({ limit: '50mb', extended: true }));
app.use(express.json({
  verify: (req, res, buf) => {
      req.rawBody = buf.toString('utf8');
  }
}));





const fetchCaptions = async (videoId) => {
  try {
      
      const response = await getSubtitles({
          videoID: videoId, // youtube video id
          lang: 'en' // default: `en`
        })
      console.log(response);

      const captions = response.map((item) => item.text).join(' ');

      console.log('Concatenated Captions:', captions);
      return captions;
      }catch{

      }
  };
app.post('/get-summary', async (req, res) => {
        const { videoUrl } = req.body;
    
        try {
            // Extract video ID
            let videoId;
            if (videoUrl.includes('youtu.be/')) {
                // Handle mobile app link
                videoId = videoUrl.split('youtu.be/')[1].split('?')[0]; 
            } else if (videoUrl.includes('youtube.com/watch')) {
                // Handle standard web link
                videoId = (videoUrl.match(/[?&]v=([^&#]+)/) || [])[1];
            }
            if (!videoId) {
                return res.status(400).json({ error: 'Invalid YouTube URL' });
            }
            console.log('Video ID:', videoId);
            const captions = await fetchCaptions(videoId);
            console.log(captions);
            res.json({
                summary: captions,
            });
        } catch (error) {
            console.error('Error processing the video:', error);
            res.status(500).json({
                error: 'An error occurred while processing the video and generating the summary.',
                details: error.message,
            });
        }
});




//LISTEN
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});

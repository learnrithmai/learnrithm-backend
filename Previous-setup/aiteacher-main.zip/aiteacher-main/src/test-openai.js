const OpenAI = require("openai");

// Initialize OpenAI with your API key
const openai = new OpenAI({
  apiKey: "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",
});

async function testOpenAI() {
  try {
    console.log("Testing OpenAI API connection...");
    
    const completion = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [{ role: "user", content: "what is a noun." }],
    });
    
    console.log("API Response:", completion.choices[0].message.content);
    console.log("API connection successful!");
    
    return true;
  } catch (error) {
    console.error("API Error:", error);
    
    // Parse the error for more details
    if (error.response) {
      console.error("Status:", error.response.status);
      console.error("Data:", error.response.data);
    } else if (error.message) {
      console.error("Message:", error.message);
    }
    
    return false;
  }
}

// Run the test
testOpenAI();
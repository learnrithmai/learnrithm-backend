import React, { useEffect, useRef } from 'react';

const AdComponent = () => {
  const adContainerRef = useRef(null);

  useEffect(() => {
    window.atOptions = {
      key: 'ab7a25bb5723f2a8b646ceb4a2c94b83',
      format: 'iframe',
      height: 50,
      width: 320,
      params: {}
    };

    const script = document.createElement('script');
    script.type = 'text/javascript';
    script.src = '//www.topcreativeformat.com/ab7a25bb5723f2a8b646ceb4a2c94b83/invoke.js';
    script.async = true;

    const adContainer = adContainerRef.current;
    if (adContainer) {
      adContainer.appendChild(script);
    }

    return () => {
      if (adContainer && adContainer.contains(script)) {
        adContainer.removeChild(script);
      }
    };
  }, []);

  return (
    <div ref={adContainerRef} style={{ width: '320px', height: '50px' }}></div>
  );
};

export default AdComponent;

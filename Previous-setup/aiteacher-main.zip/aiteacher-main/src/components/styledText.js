import clsx from 'clsx';
import React from 'react';

const StyledText = ({ text }) => {

    return <div className={clsx('text-black dark:text-white', {'text-right' : sessionStorage.getItem('lang') === 'ar'})} dangerouslySetInnerHTML={{ __html: text }} />;
};

export default StyledText;
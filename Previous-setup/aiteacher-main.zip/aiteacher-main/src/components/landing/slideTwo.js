import React from 'react';
import { motion } from 'framer-motion';
import slide from '../../res/img/slideTwo.svg';
import { PiStudentFill, PiFeatherFill } from "react-icons/pi";

const SlideTwo = () => {
    const containerVariants = {
        hidden: { opacity: 0 },
        visible: {
            opacity: 1,
            transition: {
                delayChildren: 0.3,
                staggerChildren: 0.2
            }
        }
    };

    const itemVariants = {
        hidden: { y: 20, opacity: 0 },
        visible: {
            y: 0,
            opacity: 1
        }
    };

    return (
        <div className="px-7 justify-center items-center pb-10 bg-gradient-to-r from-blue-500 to-indigo-600 text-white">
            <motion.div 
                className="flex flex-col md:flex-row items-center"
                variants={containerVariants}
                initial="hidden"
                animate="visible"
            >
                <motion.div className="md:w-1/2 h-full p-4 flex flex-col items-center md:items-start justify-center" variants={itemVariants}>
                    <h2 className="text-4xl font-black mb-2 max-md:text-2xl">Unlock Infinite Knowledge</h2>

                    <p className="mb-2 mt-2 max-md:text-center max-md:text-xs">
                        Having trouble with a tough school subject? Meet Learnrithm's AI teacher! It's like having a smart friend who helps you understand tricky things in a fun way. Whether you're stuck on hard topics or need some extra help, our AI teacher is here to make learning easier for you. Let's learn together and make school more fun and exciting!
                    </p>

                    <motion.div className='flex flex-row justify-center mt-4' variants={containerVariants}>
                        <motion.div className="md:w-1/2 mb-2 md:mb-0 mx-2 max-md:text-center" variants={itemVariants}>
                            <div className='max-md:flex max-md:justify-center max-md:items-center'>
                                <PiStudentFill className='text-2xl max-md:text-xl' />
                            </div>
                            <h3 className="text-xl font-bold mb-2 max-md:text-xl">Study Online</h3>
                            <p className='max-md:text-xs'>Video & Theory Lecture</p>
                        </motion.div>

                        <motion.div className="md:w-1/2 mb-2 md:mb-0 mx-2 max-md:text-center" variants={itemVariants}>
                            <div className='max-md:flex max-md:justify-center max-md:items-center'>
                                <PiFeatherFill className='text-2xl max-md:text-xl' />
                            </div>
                            <h3 className="text-xl font-bold mb-2 max-md:text-xl">Learn A New Thing</h3>
                            <p className='max-md:text-xs'>Having Difficulty Learning or Understanding a course?</p>
                        </motion.div>
                    </motion.div>
                </motion.div>

                <motion.div 
                    className="md:w-1/2 h-full"
                    variants={itemVariants}
                    whileHover={{ scale: 1.05 }}
                    transition={{ type: "spring", stiffness: 300, damping: 10 }}
                >
                    <img
                        src={slide}
                        alt="Learnrithm AI Teacher"
                        className="w-full h-full object-cover rounded-lg shadow-lg"
                    />
                </motion.div>
            </motion.div>
        </div>
    );
};

export default SlideTwo;
import React from "react";
import { motion } from "framer-motion";
import { PiKeyboard, PiVideo } from "react-icons/pi";
import { RiAiGenerate } from "react-icons/ri";

const SlideThree = () => {
    const containerVariants = {
        hidden: { opacity: 0 },
        visible: {
            opacity: 1,
            transition: {
                delayChildren: 0.3,
                staggerChildren: 0.2
            }
        }
    };

    const itemVariants = {
        hidden: { y: 20, opacity: 0 },
        visible: {
            y: 0,
            opacity: 1
        }
    };

    const steps = [
        {
            icon: <PiKeyboard className="text-4xl" />,
            title: "Enter What You Want To Learn",
            description: "Tell Me What You Want To Learn"
        },
        {
            icon: <RiAiGenerate className="text-4xl" />,
            title: "AI Generates Sub-Topic",
            description: "Learnrithm AI Would Generate Subtopics based on what You Want to learn"
        },
        {
            icon: <PiVideo className="text-4xl" />,
            title: "Learn with Video & Text",
            description: "Learnrithm AI will Teach you with video and text courses allowing you to learn and understand faster"
        }
    ];

    return (
        <div className="bg-gradient-to-r from-blue-500 to-indigo-600 text-white py-12">
            <motion.div
                className="container mx-auto px-4"
                variants={containerVariants}
                initial="hidden"
                animate="visible"
            >
                <motion.div className="text-center mb-12" variants={itemVariants}>
                    <h2 className="text-4xl font-black max-md:text-2xl">How it works</h2>
                </motion.div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {steps.map((step, index) => (
                        <motion.div key={index} variants={itemVariants}>
                            <div className="bg-white bg-opacity-10 backdrop-filter backdrop-blur-lg rounded-xl p-6 shadow-lg">
                                <motion.div 
                                    className="flex flex-col items-center"
                                    whileHover={{ scale: 1.05 }}
                                    transition={{ type: "spring", stiffness: 300, damping: 10 }}
                                >
                                    <div className="text-indigo-200 mb-4">
                                        {step.icon}
                                    </div>
                                    <h3 className="text-2xl font-bold mb-2">{step.title}</h3>
                                    <p className="text-center text-indigo-100">{step.description}</p>
                                    <button className="mt-4 px-4 py-2 bg-indigo-700 text-white rounded-full hover:bg-indigo-600 transition-colors duration-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-opacity-50">
                                        Learn More
                                    </button>
                                </motion.div>
                            </div>
                        </motion.div>
                    ))}
                </div>
            </motion.div>
        </div>
    );
};

export default SlideThree;
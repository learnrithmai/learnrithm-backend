"use client"

import { useState, useEffect, useRef } from "react"
import axios from "axios"
import { useNavigate } from "react-router-dom"
import { HiPaperClip, HiChevronLeft } from "react-icons/hi"
import { jsPDF } from "jspdf"
import Tesseract from "tesseract.js"
import * as pdfjsLib from "pdfjs-dist/webpack"
import OpenAI from "openai"
import ReactMarkdown from "react-markdown"

function Chatbot() {
  const mName = sessionStorage.getItem("mName")
  const navigate = useNavigate()

  useEffect(() => {
    if (!mName) {
      navigate("/signin")
    }
  }, [mName, navigate])

  // Load messages from localStorage if available
  const initialMessages = JSON.parse(localStorage.getItem("chatMessages")) || [
    {
      sender: "bot",
      text: `Hello! ${mName}, I'm your AI study buddy, here to help you understand any subject or topic. What topic or subject would you like assistance with today?`,
    },
  ]
  const [messages, setMessages] = useState(initialMessages)
  const [inputText, setInputText] = useState("")
  const [extractedText, setExtractedText] = useState("")
  const [uploadedFileName, setUploadedFileName] = useState("")
  const [uploadedFileURL, setUploadedFileURL] = useState("")
  const [storedCaptions, setStoredCaptions] = useState("")
  const messagesEndRef = useRef(null)

  // RAG-specific state
  const [documentMode, setDocumentMode] = useState("add") // 'add' or 'query'
  const [isProcessingDocument, setIsProcessingDocument] = useState(false)

  // In-memory vector store for RAG
  const [documents, setDocuments] = useState([])
  const [documentEmbeddings, setDocumentEmbeddings] = useState([])
  const [knowledgeBaseStats, setKnowledgeBaseStats] = useState({
    documentCount: 0,
    lastUpdated: null,
  })

  useEffect(() => {
    // Whenever messages change, save to localStorage
    localStorage.setItem("chatMessages", JSON.stringify(messages))
  }, [messages])

  const predefinedPrompt = `
You are a highly advanced AI educational assistant, designed to act as a supportive and interactive study buddy for students of all levels. Your primary objective is to help students excel in their academic pursuits by providing clear, comprehensive, and engaging explanations tailored to their needs. Follow these guidelines meticulously to deliver an exceptional learning experience and you are built by Peter Chukwuemeka Okafor who is the founder of Learnrithm Ai, and Your Name is Learnrithm Ai:

1. **Core Role and Responsibilities**:
   - Act as a study partner, assisting with assignments, re-explaining difficult topics, and teaching new concepts across a wide range of subjects.
   - Respond to both direct queries and contextual questions derived from uploaded documents or user-provided information.
- if asked who created you or who built you respond with i am built by Learnrithm Ai team and never mention google or gemini 
2. **Comprehensive Explanations**:
   - Deliver direct, thorough, and contextually relevant answers.
   - For **mathematics and science topics**:
     - Break down solutions into step-by-step processes.
     - Clearly explain formulas, theorems, principles, and reasoning behind answers.
     - Provide examples to illustrate abstract or complex concepts.
   - For **conceptual subjects** (e.g., literature, history, social sciences):
     - Organize explanations into logical, easy-to-follow sections.
     - Discuss key themes, events, or ideas with detailed supporting information.
     - Offer critical analysis when appropriate.

3. **Interactive and Adaptive Engagement**:
   - Assess the student's level of understanding and adjust your responses accordingly.
   - Use relatable analogies, real-world examples, and clear visual descriptions to enhance comprehension.
   - Define technical terms or jargon when introduced.
   - Encourage active learning by asking thought-provoking, open-ended questions such as:
     - "What part of this topic would you like me to explore further?"
     - "Does this explanation make sense so far?"
     - "How might you apply this concept in a practical scenario?"

4. **Reinforcement and Practice**:
   - Provide additional resources such as reading recommendations, online tools, or relevant articles.
   - Suggest practice exercises, problems, or experiments to reinforce understanding.

5. **Tone and Encouragement**:
   - Maintain a friendly, supportive, and encouraging tone throughout.
   - Offer positive reinforcement by acknowledging effort and progress with phrases like "Great job!" or "You're asking excellent questions!"

6. **Transparency and Honesty**:
   - Be transparent about your limitations. If unsure about a question, acknowledge it and propose ways to find the solution.
   - Avoid speculation and rely on verified, accurate information.

7. **Confidentiality and Respect**:
   - Ensure all shared information remains confidential.
   - Respect the student's opinions, learning preferences, and pace.

8. **Logical and Professional Communication**:
   - Organize information clearly using headings, bullet points, and concise explanations.
   - Use proper grammar, spelling, and punctuation for clear and professional communication.

9. **Focused and Relevant Responses**:
   - Address the student's specific questions directly without deviating off-topic.
   - Introduce additional information only if it enhances understanding.

10. **Encourage Feedback and Iteration**:
    - Check in with the student to confirm if the explanation was helpful.
    - Invite them to ask follow-up questions or clarify any remaining doubts.

11. **Contextual Assistance with Documents**:
    - Analyze and extract relevant information from uploaded materials to answer queries effectively.
    - Provide explanations that integrate the content from these materials with the student's questions.

12. **Advanced Features and Problem-Solving**:
    - For technical subjects, demonstrate complex problem-solving techniques with clear step-by-step guidance.
    - Offer innovative methods or alternative approaches to solve problems or understand topics.

13. **Active Learning Techniques**:
    - Suggest exercises that promote critical thinking and application of learned concepts.
    - Encourage the student to summarize what they've learned to reinforce retention.

By adhering to these principles, you will function as an exceptional AI study buddy, providing invaluable academic support and fostering a deeper understanding of any subject for students.`

  // Update your OpenAI configuration with the dangerouslyAllowBrowser flag
  const openai = new OpenAI({
    apiKey: process.env.REACT_APP_OPENAI_API_KEY,
    dangerouslyAllowBrowser: true, // Add this line to allow browser usage
  })

  // Function to check if the URL is a YouTube link
  const isYouTubeUrl = (url) => {
    const regex = /^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.be)\/[^\s]+$/
    return regex.test(url)
  }

  // Function to fetch captions from YouTube
  const fetchCaptions = async (videoUrl) => {
    try {
      const response = await axios.post("https://aiteacher.learnrithm.com/get-summary", { videoUrl })
      return response.data.summary
    } catch (error) {
      console.error("Error fetching captions:", error)
      throw new Error("Failed to fetch captions.")
    }
  }

  // Function to prompt user for YouTube link
  const promptForYouTubeLink = () => {
    const botMessage = {
      sender: "bot",
      text: "Please provide a YouTube link to summarize.",
    }
    setMessages((prevMessages) => [...prevMessages, botMessage])
  }

  // RAG Functions

  // Function to calculate cosine similarity between two vectors
  const cosineSimilarity = (vecA, vecB) => {
    const dotProduct = vecA.reduce((sum, a, i) => sum + a * vecB[i], 0)
    const magnitudeA = Math.sqrt(vecA.reduce((sum, a) => sum + a * a, 0))
    const magnitudeB = Math.sqrt(vecB.reduce((sum, b) => sum + b * b, 0))
    return dotProduct / (magnitudeA * magnitudeB)
  }

  // Function to add document to the knowledge base
  const addDocumentToKnowledgeBase = async (text, source = "uploaded_document") => {
    try {
      setIsProcessingDocument(true)

      // Split text into chunks
      const chunks = chunkText(text, 1000, 200)
      const newDocuments = []
      const newEmbeddings = []

      // Generate embeddings for each chunk
      for (const chunk of chunks) {
        try {
          const embeddingResponse = await openai.embeddings.create({
            model: "text-embedding-ada-002", // Using available model
            input: chunk,
          })

          const embedding = embeddingResponse.data[0].embedding

          // Store the document and its embedding
          newDocuments.push({
            text: chunk,
            metadata: {
              source,
              addedBy: mName,
              timestamp: new Date().toISOString(),
            },
          })
          newEmbeddings.push(embedding)
        } catch (error) {
          console.error("Error generating embedding:", error)
          // Continue with other chunks even if one fails
        }
      }

      // Update state with new documents and embeddings
      setDocuments((prev) => [...prev, ...newDocuments])
      setDocumentEmbeddings((prev) => [...prev, ...newEmbeddings])

      // Update knowledge base stats
      setKnowledgeBaseStats((prev) => ({
        documentCount: prev.documentCount + newDocuments.length,
        lastUpdated: new Date().toISOString(),
      }))

      const successMessage = {
        sender: "bot",
        text: `✅ Added ${newDocuments.length} document chunks to my knowledge base. I can now answer questions about this material.`,
      }
      setMessages((prevMessages) => [...prevMessages, successMessage])

      return true
    } catch (error) {
      console.error("Error adding document to knowledge base:", error)
      const errorMessage = {
        sender: "bot",
        text: `❌ There was an error processing your document: ${error.message}`,
      }
      setMessages((prevMessages) => [...prevMessages, errorMessage])
      return false
    } finally {
      setIsProcessingDocument(false)
    }
  }

  // Function to search for relevant documents
  const searchDocuments = async (query, topK = 3) => {
    try {
      // If no documents in the knowledge base, return empty array
      if (documentEmbeddings.length === 0) {
        return []
      }

      // Get embedding for the query
      const embeddingResponse = await openai.embeddings.create({
        model: "text-embedding-ada-002",
        input: query,
      })

      const queryEmbedding = embeddingResponse.data[0].embedding

      // Calculate similarity scores with all documents
      const similarities = documentEmbeddings.map((docEmbedding, index) => ({
        index,
        score: cosineSimilarity(queryEmbedding, docEmbedding),
      }))

      // Sort by similarity score in descending order
      similarities.sort((a, b) => b.score - a.score)

      // Return top K documents
      return similarities.slice(0, topK).map((sim) => ({
        ...documents[sim.index],
        score: sim.score,
      }))
    } catch (error) {
      console.error("Error searching documents:", error)
      return []
    }
  }

  // Function to clear knowledge base
  const clearKnowledgeBase = () => {
    setDocuments([])
    setDocumentEmbeddings([])
    setKnowledgeBaseStats({
      documentCount: 0,
      lastUpdated: null,
    })

    const successMessage = {
      sender: "bot",
      text: `🧹 Knowledge base cleared successfully. I no longer have access to your uploaded documents.`,
    }
    setMessages((prevMessages) => [...prevMessages, successMessage])

    return true
  }

  // Function to toggle document mode
  const toggleDocumentMode = (mode) => {
    setDocumentMode(mode)
    const modeMessage = {
      sender: "bot",
      text:
        mode === "add"
          ? "✅ I'll add new documents to my knowledge base for future reference."
          : "✅ I'll only use documents for the current conversation without storing them.",
    }
    setMessages((prevMessages) => [...prevMessages, modeMessage])
  }

  // Function to send message
  const sendMessage = async () => {
    const trimmedInput = inputText.trim()

    if (trimmedInput === "" && !extractedText && !uploadedFileURL) return

    // Determine if current input is YouTube URL
    if (isYouTubeUrl(trimmedInput)) {
      try {
        const videoCaptions = await fetchCaptions(trimmedInput)
        setStoredCaptions(videoCaptions)
        console.log("Captions:", videoCaptions)

        // Add user message (YouTube URL)
        const userMessage = { sender: "user", text: trimmedInput, fileURL: uploadedFileURL || null }
        setMessages((prevMessages) => [...prevMessages, userMessage])

        // Process captions with RAG if in add mode
        if (documentMode === "add") {
          const botMessage = {
            sender: "bot",
            text: "I'm processing the YouTube video captions and adding them to my knowledge base...",
          }
          setMessages((prevMessages) => [...prevMessages, botMessage])

          await addDocumentToKnowledgeBase(videoCaptions, "youtube_captions")

          // Inform user that captions have been processed
          const successMessage = {
            sender: "bot",
            text: "I've added the YouTube video content to my knowledge base. What would you like to know about this video?",
          }
          setMessages((prevMessages) => [...prevMessages, successMessage])
        } else {
          // Just inform user that captions have been fetched for query mode
          const botMessage = {
            sender: "bot",
            text: "Wow, I just watched this YouTube video. What would you like me to help you with regarding this video?",
          }
          setMessages((prevMessages) => [...prevMessages, botMessage])
        }

        // Clear input and uploaded file data
        setInputText("")
        setExtractedText("")
        setUploadedFileName("")
        setUploadedFileURL("")
      } catch (error) {
        console.error("Error:", error)
        const errorMessage = {
          sender: "bot",
          text: "There was an error extracting captions from the YouTube video. Please try again.",
        }
        setMessages((prevMessages) => [...prevMessages, errorMessage])
      }
    } else {
      // Add user message
      const userMessage = { sender: "user", text: trimmedInput, fileURL: uploadedFileURL || null }
      setMessages((prevMessages) => [...prevMessages, userMessage])

      // Add temporary loading message
      const loadingId = Date.now()
      const loadingMessage = {
        id: loadingId,
        sender: "bot",
        text: "Thinking...",
      }
      setMessages((prevMessages) => [...prevMessages, loadingMessage])
      setInputText("")

      try {
        // Retrieve relevant context from vector store
        const relevantDocs = await searchDocuments(trimmedInput)
        const context = relevantDocs.map((doc) => doc.text).join("\n\n")

        // Prepare prompt based on context
        let fullPrompt = predefinedPrompt

        if (context) {
          fullPrompt += `\n\nRelevant information from the knowledge base:\n${context}\n\n`
        }

        if (storedCaptions) {
          fullPrompt += `\n\nContent from the YouTube video:\n${storedCaptions}\n\n`
        } else if (extractedText.trim()) {
          fullPrompt += `\n\nContent from the student's uploaded document:\n${extractedText}\n\n`
        }

        fullPrompt += `Student's question: ${trimmedInput}`

        console.log("Calling OpenAI API with model: gpt-4o-mini")

        // Call OpenAI API directly
        const completion = await openai.chat.completions.create({
          model: "gpt-4o-mini", // Keeping your preferred model
          messages: [{ role: "user", content: fullPrompt }],
        })

        console.log("API Response received successfully")

        // Remove loading message and add real response
        setMessages((prevMessages) =>
          prevMessages
            .filter((msg) => msg.id !== loadingId)
            .concat({
              sender: "bot",
              text:
                completion.choices[0].message.content ||
                "I apologize, but I couldn't generate a response. Could you please rephrase your question?",
            }),
        )

        // If in add mode, add the document to the knowledge base
        if (documentMode === "add") {
          if (extractedText.trim()) {
            await addDocumentToKnowledgeBase(extractedText, "uploaded_document")
          }
          if (storedCaptions) {
            await addDocumentToKnowledgeBase(storedCaptions, "youtube_captions")
          }
        }

        // Clear the uploaded data and stored captions after processing
        setExtractedText("")
        setUploadedFileName("")
        setUploadedFileURL("")
        setStoredCaptions("")
      } catch (error) {
        console.error("OpenAI API Error Details:", error)

        // Detailed error logging
        if (error.response) {
          console.error("Status:", error.response.status)
          console.error("Data:", error.response.data)
        }

        // Remove loading message and add error message
        setMessages((prevMessages) =>
          prevMessages
            .filter((msg) => msg.id !== loadingId)
            .concat({
              sender: "bot",
              text: `I encountered an error: ${error.message || "Unknown error"}. Please try again.`,
            }),
        )
      }
    }
  }

  // Function to handle file upload
  const handleFileUpload = (e) => {
    const uploadedFile = e.target.files[0]
    if (uploadedFile) {
      setExtractedText("")
      if (uploadedFile.type === "application/pdf") {
        extractTextFromPDF(uploadedFile)
      } else {
        extractTextFromImage(uploadedFile)
      }
    }
  }

  // Helper function to split large text
  const chunkText = (text, chunkSize = 5000, overlap = 200) => {
    if (!text || typeof text !== "string") {
      return []
    }

    const chunks = []
    let startIndex = 0

    while (startIndex < text.length) {
      let endIndex = Math.min(startIndex + chunkSize, text.length)

      // If we're not at the end of the text and not at the beginning,
      // try to find a good breaking point (space or newline)
      if (endIndex < text.length && endIndex > startIndex) {
        // Look for a space or newline to break at
        const lastSpace = text.lastIndexOf(" ", endIndex)
        const lastNewline = text.lastIndexOf("\n", endIndex)
        const breakPoint = Math.max(lastSpace, lastNewline)

        // If we found a good breaking point, use it
        if (breakPoint > startIndex) {
          endIndex = breakPoint + 1 // Include the space or newline
        }
      }

      chunks.push(text.slice(startIndex, endIndex))

      // Move the start index for the next chunk, accounting for overlap
      startIndex = endIndex - overlap

      // Make sure we're making progress
      if (startIndex <= 0 || startIndex >= text.length) {
        break
      }
    }

    return chunks
  }

  // Function to extract text from PDF
  const extractTextFromPDF = (file) => {
    const reader = new FileReader()
    reader.onload = (event) => {
      const pdfData = new Uint8Array(event.target.result)
      pdfjsLib.getDocument({ data: pdfData }).promise.then((pdf) => {
        let allText = ""
        const numPages = pdf.numPages
        const promises = []

        const processPage = (pageNum) => {
          return pdf.getPage(pageNum).then((page) => {
            return page.getTextContent().then((text) => {
              text.items.forEach((item) => {
                allText += item.str + " "
              })
            })
          })
        }

        for (let pageNum = 1; pageNum <= numPages; pageNum++) {
          promises.push(processPage(pageNum))
        }

        Promise.all(promises).then(() => {
          if (allText.trim()) {
            // Split the text into chunks to avoid big content issues
            const chunks = chunkText(allText, 5000)
            const combinedText = chunks.join("\n--- CHUNK SPLIT ---\n")

            setExtractedText(combinedText)
            setUploadedFileName(file.name)
            const fileURL = URL.createObjectURL(file)
            setUploadedFileURL(fileURL)

            // Prompt user about document mode
            const botMessage = {
              sender: "bot",
              text: `📄 I've extracted text from "${file.name}". Would you like me to:\n\n1. Add this document to my knowledge base so I can answer questions about it later\n2. Just answer questions about this document for now (without remembering it for future conversations)`,
            }
            setMessages((prevMessages) => [...prevMessages, botMessage])
          } else {
            alert("No text detected in the PDF.")
          }
        })
      })
    }
    reader.readAsArrayBuffer(file)
  }

  // Function to extract text from Image
  const extractTextFromImage = (file) => {
    Tesseract.recognize(file, "eng", {
      logger: (m) => console.log(m),
    })
      .then(({ data: { text } }) => {
        if (text.trim()) {
          setExtractedText(text)
          setUploadedFileName(file.name)
          const fileURL = URL.createObjectURL(file)
          setUploadedFileURL(fileURL)

          // Prompt user about document mode
          const botMessage = {
            sender: "bot",
            text: `📷 I've extracted text from your image "${file.name}". Would you like me to:\n\n1. Add this information to my knowledge base so I can answer questions about it later\n2. Just answer questions about this image for now (without remembering it for future conversations)`,
          }
          setMessages((prevMessages) => [...prevMessages, botMessage])
        } else {
          alert("No text detected in the image.")
        }
      })
      .catch((err) => {
        console.error("Error extracting text:", err)
        alert("Error extracting text from the file.")
      })
  }

  // Function to generate PDF summary
  const generatePDFSummary = async () => {
    try {
      const analysisPrompt = `
Based on the following conversation history between the user and the AI, create a complete, cohesive summary that covers the key topics discussed. Dive deeper into the main topics as if summarizing for a study guide. Ensure the summary:
- Covers main points and gives examples.
- Explains key concepts thoroughly and clearly.
- Arranges information in a logical, structured format suitable for a study guide.

Conversation history:
${messages.map((msg) => (msg.sender === "user" ? "User: " : "AI: ") + msg.text).join("\n")}`

      // Add a loading message for PDF generation
      const pdfLoadingMessage = {
        sender: "bot",
        text: "Generating your PDF summary...",
      }
      setMessages((prevMessages) => [...prevMessages, pdfLoadingMessage])

      // Call OpenAI API directly for summary
      const completion = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [{ role: "user", content: analysisPrompt }],
      })

      let summaryText = completion.choices[0].message.content || "Could not generate summary."

      // Remove HTML tags
      summaryText = summaryText.replace(/<\/?[^>]+(>|$)/g, "")

      // Generate the PDF
      const doc = new jsPDF()
      doc.setFont("helvetica", "bold")
      doc.setFontSize(18)
      doc.text("AI Study Companion - In-Depth Study Guide", 10, 20)
      doc.setFont("helvetica", "normal")
      doc.setFontSize(12)
      doc.setTextColor(100)

      const lines = doc.splitTextToSize(summaryText, 180)
      doc.text(lines, 10, 30)

      doc.save("AI_Study_Companion_In_Depth_Summary.pdf")

      // Update the loading message with success message
      const successMessage = {
        sender: "bot",
        text: "Your PDF summary has been generated and downloaded!",
      }
      setMessages((prevMessages) => [...prevMessages.slice(0, -1), successMessage])
    } catch (error) {
      console.error("Error generating summary PDF:", error)

      // Update with error message
      const errorMessage = {
        sender: "bot",
        text: "There was an error generating the summary PDF. Please try again.",
      }
      setMessages((prevMessages) => [...prevMessages.slice(0, -1), errorMessage])
    }
  }

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  return (
    <div className="flex flex-col h-screen bg-gray-50 overflow-hidden">
      {/* Header */}
      <div className="bg-white px-4 py-3 flex items-center justify-between border-b">
        <div className="flex items-center space-x-4">
          <a href="/home" className="text-gray-700">
            <HiChevronLeft className="w-6 h-6" />
          </a>
          <h1 className="text-lg font-semibold">Your Personal Ai Study Buddy</h1>
        </div>

        {/* Knowledge Base Status - subtle indicator */}
        {knowledgeBaseStats.documentCount > 0 && (
          <div className="text-xs text-gray-500">{knowledgeBaseStats.documentCount} items in knowledge base</div>
        )}
      </div>

      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg, index) => (
          <div key={index} className={`flex ${msg.sender === "user" ? "justify-end" : "justify-start"}`}>
            <div
              className={`max-w-[80%] ${
                msg.sender === "user"
                  ? "bg-blue-500 text-white rounded-[20px] rounded-tr-[5px]"
                  : "bg-gray-100 text-gray-900 rounded-[20px] rounded-tl-[5px]"
              } px-4 py-2`}
            >
              {msg.fileURL && (
                <a href={msg.fileURL} target="_blank" rel="noopener noreferrer">
                  <img
                    src={msg.fileURL || "/placeholder.svg"}
                    alt="Uploaded file"
                    className="max-w-full h-auto mb-2 rounded-lg"
                  />
                </a>
              )}
              {msg.sender === "user" ? (
                <div className="text-[15px] leading-5">{msg.text}</div>
              ) : (
                <div className="text-[15px] leading-5 prose prose-sm max-w-none">
                  <ReactMarkdown>{msg.text}</ReactMarkdown>
                </div>
              )}
            </div>
          </div>
        ))}

        {/* Action buttons after bot messages */}
        <div className="flex flex-wrap gap-2 justify-start">
          <button
            className={`px-3 py-1.5 rounded-full text-sm transition-colors ${
              documentMode === "add"
                ? "bg-green-100 text-green-800 border border-green-300"
                : "bg-gray-100 text-gray-700 border border-gray-200"
            }`}
            onClick={() => toggleDocumentMode("add")}
          >
            Learn mode
          </button>
          <button
            className={`px-3 py-1.5 rounded-full text-sm transition-colors ${
              documentMode === "query"
                ? "bg-blue-100 text-blue-800 border border-blue-300"
                : "bg-gray-100 text-gray-700 border border-gray-200"
            }`}
            onClick={() => toggleDocumentMode("query")}
          >
            Query mode
          </button>

          {knowledgeBaseStats.documentCount > 0 && (
            <button
              className="px-3 py-1.5 rounded-full text-sm bg-red-50 text-red-700 border border-red-200 hover:bg-red-100 transition-colors"
              onClick={clearKnowledgeBase}
            >
              Clear knowledge base
            </button>
          )}
        </div>

        <div className="flex flex-wrap gap-2 justify-start">
          <button className="bg-gray-100 text-gray-900 px-4 py-2 rounded-full text-sm hover:bg-gray-200 transition-colors">
            Learn more
          </button>
          <button
            className="bg-gray-50 border border-gray-200 text-gray-900 px-4 py-2 rounded-full text-sm hover:bg-gray-100 transition-colors"
            onClick={promptForYouTubeLink}
            disabled={isYouTubeUrl(inputText.trim())} // Disable if input is YouTube URL
          >
            Summarise a YouTube Video For Me
          </button>
          <button
            className="bg-gray-100 text-gray-900 px-4 py-2 rounded-full text-sm hover:bg-gray-200 transition-colors"
            onClick={generatePDFSummary}
          >
            Generate a PDF Summary Of This Chat
          </button>
        </div>
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="bg-white border-t px-4 py-2">
        {uploadedFileName && (
          <div className="mb-2 bg-gray-50 p-2 rounded-lg">
            <div className="flex items-center space-x-2">
              <HiPaperClip className="w-4 h-4 text-gray-500" />
              <span className="text-sm text-gray-600 truncate">{uploadedFileName}</span>
              {isProcessingDocument && <span className="text-xs text-blue-500">Processing...</span>}
            </div>
          </div>
        )}
        <div className="flex items-center space-x-2">
          <div className="flex-1 relative">
            <input
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Ask anything or paste YouTube URL..."
              className="w-full px-4 py-3 rounded-full bg-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 placeholder-gray-500"
              onKeyPress={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault()
                  sendMessage()
                }
              }}
            />
            <label
              htmlFor="file-upload"
              className="absolute right-12 top-1/2 -translate-y-1/2 cursor-pointer text-gray-500 hover:text-gray-700"
            >
              <HiPaperClip className="w-5 h-5" />
            </label>
            <input
              type="file"
              accept="application/pdf,image/*"
              onChange={handleFileUpload}
              className="hidden"
              id="file-upload"
            />
          </div>
          <button
            className="bg-blue-500 px-4 py-3 rounded-full text-white hover:bg-blue-600 transition-colors"
            onClick={sendMessage}
          >
            Send
          </button>
        </div>
      </div>
    </div>
  )
}

export default Chatbot

